
-- Create system_updates table
CREATE TABLE IF NOT EXISTS public.system_updates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'in_progress', 'completed', 'failed')),
    version TEXT NOT NULL,
    error_message TEXT,
    completed_at TIMESTAMP WITH TIME ZONE,
    initiated_by TEXT NOT NULL
);

-- Create system_logs table
CREATE TABLE IF NOT EXISTS public.system_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    level TEXT NOT NULL CHECK (level IN ('info', 'warning', 'error')),
    message TEXT NOT NULL,
    metadata JSONB
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS system_updates_created_at_idx ON public.system_updates(created_at DESC);
CREATE INDEX IF NOT EXISTS system_logs_created_at_idx ON public.system_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS system_updates_status_idx ON public.system_updates(status);

-- Set up Row Level Security (RLS)
ALTER TABLE public.system_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow read access to authenticated users"
ON public.system_updates FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow read access to authenticated users"
ON public.system_logs FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow insert to authenticated users"
ON public.system_updates FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Allow insert to authenticated users"
ON public.system_logs FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Allow update to authenticated users"
ON public.system_updates FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);
