
-- Create maintenance_tickets table
CREATE TABLE IF NOT EXISTS public.maintenance_tickets (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    customer_id UUID NOT NULL REFERENCES auth.users(id),
    technician_id UUID REFERENCES auth.users(id),
    device_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('new', 'assigned', 'in_progress', 'completed', 'cancelled')),
    priority TEXT NOT NULL CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    scheduled_for TIMESTAMP WITH TIME ZONE,
    location JSONB NOT NULL,
    CONSTRAINT valid_location CHECK (location ? 'address')
);

-- Create ticket_updates table
CREATE TABLE IF NOT EXISTS public.ticket_updates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ticket_id UUID NOT NULL REFERENCES maintenance_tickets(id),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('status_change', 'assignment', 'note', 'report')),
    content TEXT NOT NULL,
    author JSONB NOT NULL,
    CONSTRAINT valid_author CHECK (author ? 'id' AND author ? 'name' AND author ? 'role')
);

-- Create maintenance_reports table
CREATE TABLE IF NOT EXISTS public.maintenance_reports (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ticket_id UUID NOT NULL REFERENCES maintenance_tickets(id),
    findings TEXT NOT NULL,
    actions TEXT NOT NULL,
    recommendations TEXT,
    parts_used JSONB,
    technician_notes TEXT,
    completion_date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    CONSTRAINT unique_ticket_report UNIQUE (ticket_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS maintenance_tickets_customer_id_idx ON maintenance_tickets(customer_id);
CREATE INDEX IF NOT EXISTS maintenance_tickets_status_idx ON maintenance_tickets(status);
CREATE INDEX IF NOT EXISTS ticket_updates_ticket_id_idx ON ticket_updates(ticket_id);

-- Set up RLS policies
ALTER TABLE maintenance_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_reports ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own tickets"
ON maintenance_tickets FOR SELECT
TO authenticated
USING (
    customer_id = auth.uid() OR 
    technician_id = auth.uid() OR 
    EXISTS (
        SELECT 1 FROM auth.users 
        WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
    )
);

CREATE POLICY "Admins can create tickets"
ON maintenance_tickets FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM auth.users 
        WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
    )
);

CREATE POLICY "Related users can view updates"
ON ticket_updates FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM maintenance_tickets
        WHERE id = ticket_id AND (
            customer_id = auth.uid() OR
            technician_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM auth.users 
                WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
            )
        )
    )
);

CREATE POLICY "Admins and technicians can create updates"
ON ticket_updates FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM maintenance_tickets
        WHERE id = ticket_id AND (
            technician_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM auth.users 
                WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
            )
        )
    )
);

CREATE POLICY "Related users can view reports"
ON maintenance_reports FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM maintenance_tickets
        WHERE id = ticket_id AND (
            customer_id = auth.uid() OR
            technician_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM auth.users 
                WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
            )
        )
    )
);

CREATE POLICY "Technicians can create reports"
ON maintenance_reports FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM maintenance_tickets
        WHERE id = ticket_id AND (
            technician_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM auth.users 
                WHERE id = auth.uid() AND raw_user_meta_data->>'role' = 'admin'
            )
        )
    )
);
