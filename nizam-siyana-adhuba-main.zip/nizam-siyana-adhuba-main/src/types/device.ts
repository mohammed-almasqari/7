
export interface Device {
  id: string;
  model: string;
  installationDate: string;
  lastMaintenance: string;
  nextMaintenance: string;
  status: 'active' | 'needs_maintenance' | 'under_maintenance';
  
  specifications: {
    capacity: string;
    dimensions?: string;
    powerConsumption: string;
    pressure: string;
  };
  
  filters: {
    type: string;
    installationDate: string;
    replacementDate: string;
    brand: string;
    model: string;
    capacity: string;
  }[];
  
  waterQualityHistory: {
    date: string;
    tdsInput: number;
    tdsOutput: number;
    ph?: number;
    pressure?: number;
    notes?: string;
  }[];
  
  location?: {
    area: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
}

export interface DeviceBranch {
  id: string;
  name: string;
  location: {
    address: string;
    city: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  devices: Device[];
}

export interface DeviceReport {
  id: string;
  branchId: string;
  month: string;
  year: number;
  spareParts: {
    name: string;
    quantity: number;
    cost: number;
  }[];
  totalCost: number;
  maintenanceVisits: number;
  waterQualityAverage: {
    tds: number;
    ph: number;
  };
}

// Helper functions for devices
export const getDeviceStatus = (device: Device): string => {
  switch (device.status) {
    case 'active':
      return 'يعمل';
    case 'needs_maintenance':
      return 'يحتاج صيانة';
    case 'under_maintenance':
      return 'تحت الصيانة';
    default:
      return 'غير معروف';
  }
};

export const calculateNextMaintenance = (device: Device): string => {
  const lastMaintenance = new Date(device.lastMaintenance);
  // افتراضياً نضيف 3 أشهر للصيانة الدورية
  const nextMaintenance = new Date(lastMaintenance);
  nextMaintenance.setMonth(nextMaintenance.getMonth() + 3);
  return nextMaintenance.toISOString();
};

export const checkMaintenanceNeeded = (device: Device): boolean => {
  const now = new Date();
  const nextMaintenance = new Date(device.nextMaintenance);
  return now >= nextMaintenance;
};

export const getFilterStatus = (filter: Device['filters'][0]): 'good' | 'warning' | 'needs_replacement' => {
  const now = new Date();
  const replacementDate = new Date(filter.replacementDate);
  const monthsLeft = (replacementDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24 * 30);
  
  if (monthsLeft <= 0) return 'needs_replacement';
  if (monthsLeft <= 1) return 'warning';
  return 'good';
};
