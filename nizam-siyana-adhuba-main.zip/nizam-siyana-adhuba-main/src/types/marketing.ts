
export type MarketingCampaign = {
  id: string;
  name: string;
  platform: string;
  targetArea: string;
  budget: number;
  duration: string;
  type: string;
  startDate: string;
  endDate: string;
  targetAudience: string;
  reach: number;
  status: "active" | "scheduled" | "completed";
  description: string;
  engagement: number;
};
