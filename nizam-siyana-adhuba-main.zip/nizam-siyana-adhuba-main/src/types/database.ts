
export interface Database {
  public: {
    Tables: {
      system_updates: {
        Row: {
          id: string
          created_at: string
          status: 'pending' | 'in_progress' | 'completed' | 'failed'
          version: string
          error_message: string | null
          completed_at: string | null
          initiated_by: string
        }
        Insert: {
          id?: string
          created_at?: string
          status: 'pending' | 'in_progress' | 'completed' | 'failed'
          version: string
          error_message?: string | null
          completed_at?: string | null
          initiated_by: string
        }
        Update: {
          id?: string
          created_at?: string
          status?: 'pending' | 'in_progress' | 'completed' | 'failed'
          version?: string
          error_message?: string | null
          completed_at?: string | null
          initiated_by?: string
        }
      }
      system_logs: {
        Row: {
          id: string
          created_at: string
          level: 'info' | 'warning' | 'error'
          message: string
          metadata: Record<string, any> | null
        }
        Insert: {
          id?: string
          created_at?: string
          level: 'info' | 'warning' | 'error'
          message: string
          metadata?: Record<string, any> | null
        }
        Update: {
          id?: string
          created_at?: string
          level?: 'info' | 'warning' | 'error'
          message?: string
          metadata?: Record<string, any> | null
        }
      }
    }
  }
}
