
export type TicketStatus = 
  | 'new'
  | 'assigned'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface MaintenanceTicket {
  id: string;
  customer_id: string;
  technician_id?: string;
  device_id: string;
  status: TicketStatus;
  priority: TicketPriority;
  description: string;
  created_at: string;
  scheduled_for?: string;
  location: {
    address: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  updates: TicketUpdate[];
}

export interface TicketUpdate {
  id: string;
  ticket_id: string;
  timestamp: string;
  type: 'status_change' | 'assignment' | 'note' | 'report';
  content: string;
  author: {
    id: string;
    name: string;
    role: 'admin' | 'technician' | 'customer';
  };
}

