
export type UserRole = 'admin' | 'technician' | 'customer';
