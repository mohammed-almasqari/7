
export interface WaterQualityMeasurements {
  turbidity: number; // العكورة
  tds: number; // الأملاح الذائبة الكلية
  ph: number; // درجة الحموضة
  temperature: number; // درجة الحرارة
  conductivity: number; // الموصلية
}

export interface SASOStandard {
  parameter: string;
  minValue: number;
  maxValue: number;
  unit: string;
}

export interface MaintenanceReport {
  id: string;
  ticketId: string;
  technicianId: string;
  date: string;
  waterQuality: WaterQualityMeasurements;
  sasoStandards: SASOStandard[];
  partsUsed: {
    name: string;
    quantity: number;
    unitPrice: number;
  }[];
  totalCost: number;
  notes: string;
  qrCode: string;
  systemLogo: string;
  status: 'draft' | 'completed' | 'sent';
}
