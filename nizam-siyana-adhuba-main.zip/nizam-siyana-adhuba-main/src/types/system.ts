
export interface SystemVersion {
  os: string;
  app: string;
}

export interface UpdateStatus {
  isUpdating: boolean;
  lastUpdate: string | null;
  currentVersion: SystemVersion | null;
  error: string | null;
  stage: 'idle' | 'backup' | 'sync' | 'verify' | 'complete' | 'error';
}

export interface ServerConfig {
  sshHost: string;
  sshUser: string;
  sshKeyPath: string;
  repoPath: string;
  backupDir: string;
}
