import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Toaster } from "@/components/ui/toaster";
import { NotificationsProvider } from './contexts/NotificationsContext';
import CustomerDashboard from './pages/customer/Dashboard';
import AdminDashboard from './pages/admin/Dashboard';
import AdminOverview from './pages/admin/AdminOverview';
import TechnicianManagement from './pages/admin/TechnicianManagement';
import MaintenanceRequests from './pages/admin/MaintenanceRequests';
import Inventory from './pages/admin/Inventory';
import Coverage from './pages/admin/Coverage';
import Customers from './pages/admin/Customers';
import AI from './pages/admin/AI';
import Integration from './pages/admin/Integration';
import Settings from './pages/admin/Settings';
import Reports from './pages/admin/Reports';
import Finance from './pages/admin/Finance';
import Companies from './pages/admin/Companies';
import Scheduling from './pages/admin/Scheduling';
import Notifications from './pages/admin/Notifications';
import Tickets from './pages/admin/Tickets';
import Messages from './pages/admin/Messages';
import Marketing from './pages/admin/Marketing';
import SystemUpdate from './pages/admin/SystemUpdate';
import TechnicianDashboard from './pages/technician/Dashboard';
import Login from './pages/Login';
import NotFound from './pages/NotFound';
import { Layout } from './components/Layout';
import Index from './pages/Index';

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  switch (user.role) {
    case 'admin':
      if (!location.pathname.startsWith('/admin')) {
        return <Navigate to="/admin" replace />;
      }
      break;
    case 'technician':
      if (!location.pathname.startsWith('/technician')) {
        return <Navigate to="/technician" replace />;
      }
      break;
    case 'customer':
      if (!location.pathname.startsWith('/customer')) {
        return <Navigate to="/customer" replace />;
      }
      break;
  }

  return children;
};

const DashboardRouter = () => {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;

  switch (user.role) {
    case 'admin':
      return <Navigate to="/admin" replace />;
    case 'technician':
      return <Navigate to="/technician" replace />;
    case 'customer':
      return <Navigate to="/customer" replace />;
    default:
      return <Navigate to="/login" replace />;
  }
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      <Route path="/" element={
        user ? (
          <DashboardRouter />
        ) : (
          <Layout>
            <Index />
          </Layout>
        )
      } />

      <Route path="/admin" element={
        <Layout>
          <PrivateRoute>
            <AdminDashboard />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/overview" element={
        <Layout>
          <PrivateRoute>
            <AdminOverview />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/marketing" element={
        <Layout>
          <PrivateRoute>
            <Marketing />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/technicians" element={
        <Layout>
          <PrivateRoute>
            <TechnicianManagement />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/maintenance" element={
        <Layout>
          <PrivateRoute>
            <MaintenanceRequests />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/inventory" element={
        <Layout>
          <PrivateRoute>
            <Inventory />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/customers" element={
        <Layout>
          <PrivateRoute>
            <Customers />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/coverage" element={
        <Layout>
          <PrivateRoute>
            <Coverage />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/ai" element={
        <Layout>
          <PrivateRoute>
            <AI />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/integration" element={
        <Layout>
          <PrivateRoute>
            <Integration />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/reports" element={
        <Layout>
          <PrivateRoute>
            <Reports />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/finance" element={
        <Layout>
          <PrivateRoute>
            <Finance />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/companies" element={
        <Layout>
          <PrivateRoute>
            <Companies />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/scheduling" element={
        <Layout>
          <PrivateRoute>
            <Scheduling />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/notifications" element={
        <Layout>
          <PrivateRoute>
            <Notifications />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/tickets" element={
        <Layout>
          <PrivateRoute>
            <Tickets />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/messages" element={
        <Layout>
          <PrivateRoute>
            <Messages />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/admin/system-update" element={
        <Layout>
          <PrivateRoute>
            <SystemUpdate />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/customer/*" element={
        <Layout>
          <PrivateRoute>
            <CustomerDashboard />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="/technician/*" element={
        <Layout>
          <PrivateRoute>
            <TechnicianDashboard />
          </PrivateRoute>
        </Layout>
      } />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <NotificationsProvider>
          <AppRoutes />
          <Toaster />
        </NotificationsProvider>
      </Router>
    </AuthProvider>
  );
}

export default App;
