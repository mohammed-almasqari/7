import { UserRole } from "@/types/user";

export type DeviceType = 
  | 'home_ro'
  | 'home_carbon'
  | 'industrial_station'
  | 'water_tank'
  | 'pump_system';

export type FilterType =
  | 'sediment'
  | 'carbon_block'
  | 'granular_carbon'
  | 'ro_membrane'
  | 'post_carbon'
  | 'mineral'
  | 'uv';

export interface WaterQualityRecord {
  date: string;
  tdsInput: number;
  tdsOutput: number;
  ph?: number;
  pressure?: number;
  notes?: string;
}

export interface Filter {
  type: FilterType;
  installationDate: string;
  replacementDate: string;
  brand: string;
  model: string;
  capacity: string;
}

export interface Device {
  id: string;
  type: DeviceType;
  model: string;
  installationDate: string;
  lastMaintenance: string;
  nextMaintenance: string;
  status: 'active' | 'needs_maintenance' | 'under_maintenance';
  
  specifications: {
    capacity?: string;
    dimensions?: string;
    powerConsumption?: string;
    pressure?: string;
  };
  
  filters: Filter[];
  waterQualityHistory: WaterQualityRecord[];
  
  location?: {
    area: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
}

export interface MaintenanceContract {
  id: string;
  customerId: string;
  startDate: string;
  endDate: string;
  type: 'residential' | 'commercial' | 'industrial';
  visits: {
    date: string;
    completed: boolean;
    technicianId?: string;
    notes?: string;
  }[];
  deviceIds: string[];
  status: 'active' | 'expired' | 'pending_renewal';
  price: number;
}

export interface MaintenanceRequest {
  id: string;
  deviceId: string;
  date: string;
  status: 'pending' | 'in_progress' | 'completed';
  description: string;
  technicianId?: string;
  rating?: number;
  report?: {
    findings: string;
    recommendations: string;
    parts_replaced?: string[];
  };
}

export type CustomerType = 'individual' | 'commercial' | 'government';
export type TechnicianSpecialty = 'residential_systems' | 'industrial_systems' | 'infrastructure';

export interface MockUser {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  
  permissions?: string[];
  lastLogin?: string;
  managedContracts?: string[];
  
  area?: string;
  specialty?: TechnicianSpecialty[];
  expertise?: string[];
  completedJobs?: number;
  rating?: number;
  currentStatus?: 'available' | 'busy' | 'off_duty';
  certifications?: string[];
  
  customerType?: CustomerType;
  devices?: Device[];
  maintenanceHistory?: MaintenanceRequest[];
  loyaltyPoints?: number;
  memberSince?: string;
  maintenanceContracts?: MaintenanceContract[];
  discountRate?: number;
}

export const mockUsers: MockUser[] = [
  {
    id: "admin_001",
    name: "أحمد السالم",
    email: "ahmad@athoba.com",
    password: "Admin@123",
    phone: "966500000001",
    role: "admin",
    avatar: "/avatars/admin.jpg",
    permissions: [
      "manage_users",
      "view_analytics",
      "manage_campaigns",
      "manage_technicians",
      "view_reports",
      "manage_settings",
      "manage_contracts"
    ],
    lastLogin: "2024-03-20T08:30:00Z",
    managedContracts: ["cont_001", "cont_002"]
  },

  {
    id: "tech_001",
    name: "محمد العتيبي",
    email: "mohammed@athoba.com",
    password: "Tech@123",
    phone: "966500000002",
    role: "technician",
    avatar: "/avatars/tech1.jpg",
    area: "الرياض - شمال",
    specialty: ["residential_systems", "industrial_systems"],
    expertise: ["محطات تحلية", "فلترة مياه", "صيانة مضخات"],
    completedJobs: 156,
    rating: 4.8,
    currentStatus: "available",
    certifications: ["شهادة فني محطات RO", "شهادة صيانة مضخات المياه"],
  },

  {
    id: "tech_002",
    name: "عبدالله القحطاني",
    email: "abdullah@athoba.com",
    password: "Tech@456",
    phone: "966500000003",
    role: "technician",
    avatar: "/avatars/tech2.jpg",
    area: "الرياض - جنوب",
    specialty: ["residential_systems"],
    expertise: ["فلترة منزلية", "صيانة عامة"],
    completedJobs: 89,
    rating: 4.7,
    currentStatus: "busy",
    certifications: ["شهادة صيانة فلاتر المياه المنزلية"],
  },

  {
    id: "cust_001",
    name: "شركة المياه النقية",
    email: "info@purewater.com",
    password: "Cust@123",
    phone: "966500000004",
    role: "customer",
    customerType: "commercial",
    memberSince: "2023-01-15",
    loyaltyPoints: 450,
    discountRate: 10,
    devices: [
      {
        id: "dev_001",
        type: "industrial_station",
        model: "RO-5000",
        installationDate: "2023-01-20",
        lastMaintenance: "2024-03-01",
        nextMaintenance: "2024-06-01",
        status: "active",
        specifications: {
          capacity: "5000 لتر/ساعة",
          dimensions: "200x150x180 سم",
          powerConsumption: "2.2 كيلوواط",
          pressure: "6-8 بار"
        },
        filters: [
          {
            type: "sediment",
            installationDate: "2024-01-01",
            replacementDate: "2024-07-01",
            brand: "Aqua Pure",
            model: "AP110",
            capacity: "50 ميكرون"
          },
          {
            type: "carbon_block",
            installationDate: "2024-01-01",
            replacementDate: "2024-07-01",
            brand: "Aqua Pure",
            model: "AP200",
            capacity: "10 ميكرون"
          }
        ],
        waterQualityHistory: [
          {
            date: "2024-03-01",
            tdsInput: 1200,
            tdsOutput: 180,
            ph: 7.2,
            pressure: 7.5,
            notes: "جودة مياه ممتازة"
          }
        ],
        location: {
          area: "المنطقة الصناعية - الرياض",
          coordinates: {
            lat: 24.7136,
            lng: 46.6753
          }
        }
      }
    ]
  },

  {
    id: "cust_002",
    name: "سارة الغامدي",
    email: "sara@gmail.com",
    password: "Cust@456",
    phone: "966500000005",
    role: "customer",
    customerType: "individual",
    memberSince: "2024-02-01",
    loyaltyPoints: 50,
    discountRate: 5,
    devices: [
      {
        id: "dev_002",
        type: "home_ro",
        model: "Home-200",
        installationDate: "2024-02-15",
        lastMaintenance: "2024-03-15",
        nextMaintenance: "2024-06-15",
        status: "active",
        specifications: {
          capacity: "200 لتر/يوم",
          dimensions: "40x40x120 سم",
          powerConsumption: "0.4 كيلوواط",
          pressure: "3-6 بار"
        },
        filters: [
          {
            type: "sediment",
            installationDate: "2024-02-15",
            replacementDate: "2024-08-15",
            brand: "Pure Pro",
            model: "PP10",
            capacity: "10 ميكرون"
          },
          {
            type: "carbon_block",
            installationDate: "2024-02-15",
            replacementDate: "2024-08-15",
            brand: "Pure Pro",
            model: "CB5",
            capacity: "5 ميكرون"
          }
        ],
        waterQualityHistory: [
          {
            date: "2024-03-15",
            tdsInput: 850,
            tdsOutput: 120,
            ph: 7.4,
            pressure: 4.5,
            notes: "تم تنظيف الفلاتر"
          }
        ],
        location: {
          area: "حي النرجس - الرياض"
        }
      }
    ]
  }
];

export const getUserById = (id: string): MockUser | undefined => {
  return mockUsers.find(user => user.id === id);
};

export const getUsersByRole = (role: UserRole): MockUser[] => {
  return mockUsers.filter(user => user.role === role);
};

export const getUsersByCustomerType = (type: CustomerType): MockUser[] => {
  return mockUsers.filter(user => user.customerType === type);
};

export const getTechniciansBySpecialty = (specialty: TechnicianSpecialty): MockUser[] => {
  return mockUsers.filter(user => 
    user.role === 'technician' && 
    user.specialty?.includes(specialty)
  );
};
