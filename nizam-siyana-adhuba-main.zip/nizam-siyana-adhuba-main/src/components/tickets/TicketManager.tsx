import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Clock, AlertTriangle, CheckCircle, UserCheck, MapPin } from 'lucide-react';
import { MaintenanceTicket, TicketStatus, TicketPriority } from '@/types/ticket';
import { mockUsers } from '@/data/mockUsers';

interface TicketManagerProps {
  tickets: MaintenanceTicket[];
  userRole: 'admin' | 'technician' | 'customer';
  onTicketAction?: (ticketId: string, action: string, data?: any) => void;
}

const statusColors: Record<TicketStatus, string> = {
  new: 'bg-blue-500',
  assigned: 'bg-yellow-500',
  in_progress: 'bg-purple-500',
  completed: 'bg-green-500',
  cancelled: 'bg-red-500'
};

const priorityIcons: Record<TicketPriority, typeof Clock> = {
  low: Clock,
  medium: Clock,
  high: AlertTriangle,
  urgent: AlertTriangle
};

const priorityColors: Record<TicketPriority, string> = {
  low: 'text-blue-500',
  medium: 'text-yellow-500',
  high: 'text-orange-500',
  urgent: 'text-red-500'
};

export const TicketManager = ({ tickets, userRole, onTicketAction }: TicketManagerProps) => {
  const { toast } = useToast();
  
  const getStatusText = (status: TicketStatus): string => {
    const statusMap: Record<TicketStatus, string> = {
      new: 'جديد',
      assigned: 'تم التعيين',
      in_progress: 'قيد التنفيذ',
      completed: 'مكتمل',
      cancelled: 'ملغي'
    };
    return statusMap[status];
  };

  const getPriorityText = (priority: TicketPriority): string => {
    const priorityMap: Record<TicketPriority, string> = {
      low: 'منخفضة',
      medium: 'متوسطة',
      high: 'عالية',
      urgent: 'طارئة'
    };
    return priorityMap[priority];
  };

  const getTechnicians = () => {
    return mockUsers.filter(user => user.role === 'technician');
  };

  const handleAssignTechnician = (ticketId: string, technicianId: string) => {
    onTicketAction?.(ticketId, 'assign', { technicianId });
    const technician = mockUsers.find(user => user.id === technicianId);
    toast({
      title: "تم تعيين الفني",
      description: `تم تعيين ${technician?.name} للطلب رقم ${ticketId}`,
    });
  };

  const renderTicketActions = (ticket: MaintenanceTicket) => {
    switch (userRole) {
      case 'admin':
        return (
          <div className="flex gap-2">
            {ticket.status === 'new' && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <UserCheck className="h-4 w-4 ml-2" />
                    تعيين فني
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>تعيين فني للطلب</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 mt-4">
                    {getTechnicians().map(tech => (
                      <Button
                        key={tech.id}
                        variant="outline"
                        onClick={() => handleAssignTechnician(ticket.id, tech.id)}
                        className="justify-start"
                      >
                        <div className="flex items-center gap-2">
                          <UserCheck className="h-4 w-4" />
                          <span>{tech.name}</span>
                          <Badge variant="secondary" className="mr-auto">
                            {tech.completedJobs} طلب منجز
                          </Badge>
                        </div>
                      </Button>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
            )}
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onTicketAction?.(ticket.id, 'cancel')}
              disabled={['completed', 'cancelled'].includes(ticket.status)}
            >
              إلغاء
            </Button>
          </div>
        );
      case 'technician':
        return (
          <div className="flex gap-2">
            {ticket.status === 'assigned' && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => onTicketAction?.(ticket.id, 'start')}
              >
                بدء العمل
              </Button>
            )}
            {ticket.status === 'in_progress' && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => onTicketAction?.(ticket.id, 'complete')}
              >
                إنهاء
              </Button>
            )}
          </div>
        );
      case 'customer':
        return (
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => onTicketAction?.(ticket.id, 'track')}
          >
            تتبع الحالة
          </Button>
        );
    }
  };

  const filterTickets = (status: TicketStatus | 'all') => {
    if (status === 'all') return tickets;
    return tickets.filter(ticket => ticket.status === status);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>إدارة الطلبات</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="all">الكل</TabsTrigger>
            <TabsTrigger value="new">جديد</TabsTrigger>
            <TabsTrigger value="assigned">معين</TabsTrigger>
            <TabsTrigger value="in_progress">قيد التنفيذ</TabsTrigger>
            <TabsTrigger value="completed">مكتمل</TabsTrigger>
          </TabsList>

          {(['all', 'new', 'assigned', 'in_progress', 'completed'] as const).map(status => (
            <TabsContent key={status} value={status} className="space-y-4">
              {filterTickets(status).map((ticket) => (
                <div 
                  key={ticket.id}
                  className="p-4 rounded-lg border hover:border-primary transition-colors"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-semibold mb-1">{ticket.description}</h4>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        {ticket.location.address}
                      </div>
                    </div>
                    <Badge className={statusColors[ticket.status]}>
                      {getStatusText(ticket.status)}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-4 mb-4">
                    {React.createElement(priorityIcons[ticket.priority], { 
                      className: `h-4 w-4 ${priorityColors[ticket.priority]}` 
                    })}
                    <span className="text-sm">
                      الأولوية: {getPriorityText(ticket.priority)}
                    </span>
                    {ticket.scheduled_for && (
                      <>
                        <span className="text-muted-foreground">|</span>
                        <span className="text-sm">
                          الموعد: {new Date(ticket.scheduled_for).toLocaleDateString('ar-SA')}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex justify-between items-center">
                    {renderTicketActions(ticket)}
                    {ticket.technician_id && (
                      <div className="text-sm text-muted-foreground">
                        الفني: {mockUsers.find(u => u.id === ticket.technician_id)?.name}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {filterTickets(status).length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  لا توجد طلبات {status !== 'all' ? getStatusText(status) : ''} حالياً
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};
