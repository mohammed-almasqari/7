
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Building2,
  Settings,
  AlertTriangle,
  MapPin,
  CircleDollarSign,
  Activity,
  Filter,
} from 'lucide-react';
import { DeviceBranch } from '@/types/device';

interface DeviceManagerProps {
  branches: DeviceBranch[];
  onUpdateDevice: (branchId: string, deviceId: string, data: any) => void;
  onRequestMaintenance: (branchId: string, deviceId: string, priority: string) => void;
}

export const DeviceManager = ({ branches, onUpdateDevice, onRequestMaintenance }: DeviceManagerProps) => {
  const { toast } = useToast();
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);

  const handleMaintenanceRequest = (branchId: string, deviceId: string) => {
    onRequestMaintenance(branchId, deviceId, 'high');
    toast({
      title: "تم إرسال طلب الصيانة",
      description: "سيتم تعيين فني مختص في أقرب وقت",
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          إدارة الأجهزة في الفروع
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={branches[0]?.id} className="w-full">
          <TabsList className="mb-4">
            {branches.map((branch) => (
              <TabsTrigger
                key={branch.id}
                value={branch.id}
                onClick={() => setSelectedBranch(branch.id)}
              >
                {branch.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {branches.map((branch) => (
            <TabsContent key={branch.id} value={branch.id}>
              <div className="grid gap-6">
                <div className="flex items-start gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4 mt-1" />
                  <div>
                    <p>{branch.location.address}</p>
                    <p>{branch.location.city}</p>
                  </div>
                </div>

                <div className="grid gap-4">
                  {branch.devices.map((device) => (
                    <Card key={device.id}>
                      <CardContent className="pt-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="font-semibold mb-1">{device.model}</h4>
                            <p className="text-sm text-muted-foreground">
                              آخر صيانة: {new Date(device.lastMaintenance).toLocaleDateString('ar-SA')}
                            </p>
                          </div>
                          <Badge
                            variant={device.status === 'active' ? 'default' : 'destructive'}
                          >
                            {device.status === 'active' ? 'يعمل' : 'يحتاج صيانة'}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                          <div>
                            <Label className="text-muted-foreground mb-1">السعة</Label>
                            <p className="font-medium">{device.specifications.capacity}</p>
                          </div>
                          <div>
                            <Label className="text-muted-foreground mb-1">الضغط</Label>
                            <p className="font-medium">{device.specifications.pressure}</p>
                          </div>
                          <div>
                            <Label className="text-muted-foreground mb-1">استهلاك الطاقة</Label>
                            <p className="font-medium">{device.specifications.powerConsumption}</p>
                          </div>
                        </div>

                        <div className="space-x-2 space-x-reverse">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMaintenanceRequest(branch.id, device.id)}
                          >
                            <Settings className="h-4 w-4 ml-2" />
                            طلب صيانة
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};
