
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DeviceReport } from '@/types/device';
import { FileSpreadsheet, Download, TrendingUp, CircleDollarSign } from 'lucide-react';

interface MonthlyReportProps {
  report: DeviceReport;
  onDownload: (reportId: string) => void;
}

export const MonthlyReport = ({ report, onDownload }: MonthlyReportProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            تقرير شهر {report.month} {report.year}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDownload(report.id)}
          >
            <Download className="h-4 w-4 ml-2" />
            تحميل التقرير
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">إجمالي التكلفة</p>
                <CircleDollarSign className="h-4 w-4 text-green-500" />
              </div>
              <h3 className="text-2xl font-bold mt-2">
                {report.totalCost.toLocaleString('ar-SA')} ريال
              </h3>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">زيارات الصيانة</p>
                <TrendingUp className="h-4 w-4 text-blue-500" />
              </div>
              <h3 className="text-2xl font-bold mt-2">
                {report.maintenanceVisits} زيارة
              </h3>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">متوسط جودة المياه</p>
                <Badge variant="outline">
                  TDS: {report.waterQualityAverage.tds} | pH: {report.waterQualityAverage.ph}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>قطعة الغيار</TableHead>
                <TableHead>الكمية</TableHead>
                <TableHead>التكلفة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.spareParts.map((part, index) => (
                <TableRow key={index}>
                  <TableCell>{part.name}</TableCell>
                  <TableCell>{part.quantity}</TableCell>
                  <TableCell>{part.cost.toLocaleString('ar-SA')} ريال</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
