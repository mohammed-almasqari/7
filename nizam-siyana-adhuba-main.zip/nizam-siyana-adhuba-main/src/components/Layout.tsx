
import React, { useState } from "react";
import { useTheme } from "../hooks/use-theme";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Sun, Moon, Phone, Mail, LogIn, UserPlus, LogOut, Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export const Layout = ({ children }: { children: React.ReactNode }) => {
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const MenuItems = () => (
    <>
      <a href="tel:+966500000000" className="flex items-center gap-1 hover:text-primary transition-colors">
        <Phone className="h-4 w-4" />
        <span dir="ltr">+966 50 000 0000</span>
      </a>
      <a href="mailto:info@athoba.com" className="flex items-center gap-1 hover:text-primary transition-colors">
        <Mail className="h-4 w-4" />
        <span>info@athoba.com</span>
      </a>
    </>
  );

  const AuthButtons = () => (
    <>
      {user ? (
        <div className="flex items-center gap-4">
          <span className="text-sm">مرحباً، {user.name}</span>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            className="flex items-center gap-1 text-primary hover:text-primary/90"
          >
            <LogOut className="h-4 w-4" />
            <span>تسجيل الخروج</span>
          </Button>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => navigate('/login')} 
            className="flex items-center justify-center gap-1 text-primary hover:text-primary/90"
          >
            <LogIn className="h-4 w-4" />
            <span>تسجيل الدخول</span>
          </Button>
          <Button 
            size="sm"
            className="flex items-center justify-center gap-1 bg-primary text-white hover:bg-primary/90"
          >
            <UserPlus className="h-4 w-4" />
            <span>حساب جديد</span>
          </Button>
        </div>
      )}
    </>
  );

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Contact & Auth Bar - Desktop */}
      <div className="hidden sm:block bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-4 h-10 flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <MenuItems />
          </div>
          <div className="flex items-center gap-2">
            <AuthButtons />
          </div>
        </div>
      </div>
      
      {/* Main Navigation */}
      <nav className="sticky top-0 right-0 left-0 z-50 glass backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="font-cairo text-xl font-bold">نظام صيانة عذوبة</h1>
          
          <div className="flex items-center gap-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              aria-label={theme === "dark" ? "تفعيل الوضع المضيء" : "تفعيل الوضع المظلم"}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>

            {/* Mobile Menu */}
            <div className="sm:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[85vw] sm:w-[400px]">
                  <SheetHeader>
                    <SheetTitle>القائمة</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <div className="space-y-4">
                      <MenuItems />
                    </div>
                    <div className="pt-6 border-t">
                      <AuthButtons />
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      <main>
        {children}
      </main>
    </div>
  );
};
