
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Star } from 'lucide-react';

interface CustomerHeaderProps {
  name: string;
  loyaltyPoints?: number;
}

export const CustomerHeader = ({ name, loyaltyPoints }: CustomerHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-8">
      <div>
        <h1 className="text-3xl font-bold">مرحباً، {name}</h1>
        <p className="text-muted-foreground">لوحة تحكم العميل التجاري</p>
      </div>
      <div className="flex items-center gap-4">
        <Badge variant="outline" className="px-4 py-2">
          <Star className="w-4 h-4 text-yellow-500 mr-2" />
          عميل مميز
        </Badge>
        <Badge variant="secondary" className="px-4 py-2">
          النقاط: {loyaltyPoints}
        </Badge>
      </div>
    </div>
  );
};
