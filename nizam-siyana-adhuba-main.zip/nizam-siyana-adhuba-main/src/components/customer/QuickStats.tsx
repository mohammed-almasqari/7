
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Building2, Activity, Calendar, DollarSign } from 'lucide-react';

interface QuickStatsProps {
  activeDevices: number;
  waterQuality: string;
  nextMaintenance: string;
  monthlySavings: string;
}

export const QuickStats = ({ activeDevices, waterQuality, nextMaintenance, monthlySavings }: QuickStatsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Building2 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">الأجهزة النشطة</p>
              <h3 className="text-2xl font-bold">{activeDevices}</h3>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-green-100/50 to-green-50/50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-500/10 rounded-lg">
              <Activity className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">معدل جودة المياه</p>
              <h3 className="text-2xl font-bold">{waterQuality}</h3>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-blue-100/50 to-blue-50/50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">الصيانة القادمة</p>
              <h3 className="text-sm font-bold">{nextMaintenance}</h3>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-purple-100/50 to-purple-50/50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-500/10 rounded-lg">
              <DollarSign className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">التوفير الشهري</p>
              <h3 className="text-2xl font-bold">{monthlySavings}</h3>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
