
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Device } from '@/data/mockUsers';

interface WaterQualityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  device: Device | null;
}

export const WaterQualityDialog = ({ open, onOpenChange, device }: WaterQualityDialogProps) => {
  if (!device) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>تقرير جودة المياه</DialogTitle>
          <DialogDescription>سجل قراءات جودة المياه</DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          {device.waterQualityHistory.map((record, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium">{new Date(record.date).toLocaleDateString('ar-SA')}</p>
                    <div className="space-y-1 mt-2 text-sm text-muted-foreground">
                      <p>TDS المدخل: {record.tdsInput} ppm</p>
                      <p>TDS المخرج: {record.tdsOutput} ppm</p>
                      {record.ph && <p>درجة الحموضة: {record.ph}</p>}
                      {record.pressure && <p>الضغط: {record.pressure} بار</p>}
                    </div>
                  </div>
                  <Badge variant="outline">{record.notes}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};
