
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Settings, BarChart2, AlertCircle, Droplet, Clock } from 'lucide-react';
import type { Device } from '@/data/mockUsers';

interface DeviceListProps {
  devices: Device[];
  onShowDetails: (device: Device) => void;
  onShowWaterQuality: (device: Device) => void;
  onMaintenanceRequest: (deviceId: string) => void;
}

export const DeviceList = ({
  devices,
  onShowDetails,
  onShowWaterQuality,
  onMaintenanceRequest
}: DeviceListProps) => {
  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle>الأجهزة المثبتة</CardTitle>
        <CardDescription>حالة ومعلومات جميع الأجهزة</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6">
          {devices?.map((device) => (
            <Card key={device.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-lg">{device.model}</h3>
                      <Badge
                        variant={device.status === 'active' ? 'default' : 'destructive'}
                      >
                        {device.status === 'active' ? 'يعمل' : 'يحتاج صيانة'}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      آخر صيانة: {new Date(device.lastMaintenance).toLocaleDateString('ar-SA')}
                    </p>
                    <div className="flex gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Droplet className="h-4 w-4" />
                        السعة: {device.specifications.capacity}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        تاريخ التركيب: {new Date(device.installationDate).toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button 
                      variant="outline"
                      onClick={() => onShowDetails(device)}
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      تفاصيل الجهاز
                    </Button>
                    <Button
                      variant="default"
                      onClick={() => onShowWaterQuality(device)}
                    >
                      <BarChart2 className="h-4 w-4 mr-2" />
                      جودة المياه
                    </Button>
                    {device.status !== 'active' && (
                      <Button
                        variant="destructive"
                        onClick={() => onMaintenanceRequest(device.id)}
                      >
                        <AlertCircle className="h-4 w-4 mr-2" />
                        طلب صيانة
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
