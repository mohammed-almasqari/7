
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Device } from '@/data/mockUsers';

interface DeviceDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  device: Device | null;
}

export const DeviceDetailsDialog = ({ open, onOpenChange, device }: DeviceDetailsDialogProps) => {
  if (!device) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>تفاصيل الجهاز</DialogTitle>
          <DialogDescription>معلومات تفصيلية عن الجهاز وحالته</DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">المواصفات الفنية</h4>
              <div className="space-y-2 text-sm">
                <p>السعة: {device.specifications.capacity}</p>
                <p>الأبعاد: {device.specifications.dimensions}</p>
                <p>استهلاك الطاقة: {device.specifications.powerConsumption}</p>
                <p>الضغط التشغيلي: {device.specifications.pressure}</p>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2">معلومات التركيب</h4>
              <div className="space-y-2 text-sm">
                <p>تاريخ التركيب: {new Date(device.installationDate).toLocaleDateString('ar-SA')}</p>
                <p>آخر صيانة: {new Date(device.lastMaintenance).toLocaleDateString('ar-SA')}</p>
                <p>الصيانة القادمة: {new Date(device.nextMaintenance).toLocaleDateString('ar-SA')}</p>
                <p>الموقع: {device.location?.area}</p>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-medium mb-2">الفلاتر المستخدمة</h4>
            <div className="grid grid-cols-2 gap-4">
              {device.filters.map((filter) => (
                <div key={filter.type} className="p-4 border rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">{filter.brand} {filter.model}</p>
                      <p className="text-sm text-muted-foreground">النوع: {filter.type}</p>
                    </div>
                    <Badge>
                      {new Date(filter.replacementDate).toLocaleDateString('ar-SA')}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
