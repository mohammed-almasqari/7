
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export const CTASection = () => {
  const navigate = useNavigate();

  return (
    <section className="py-20 bg-gradient-to-r from-primary to-primary-foreground text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">ابدأ اليوم مع عذوبة</h2>
        <p className="text-xl mb-8 text-primary-foreground/90">
          انضم إلى آلاف العملاء الذين يثقون بنا في صيانة فلاتر مياههم
        </p>
        <Button 
          size="lg" 
          variant="secondary" 
          className="text-lg animate-pulse"
          onClick={() => navigate('/login')}
        >
          سجل الآن
        </Button>
      </div>
    </section>
  );
};
