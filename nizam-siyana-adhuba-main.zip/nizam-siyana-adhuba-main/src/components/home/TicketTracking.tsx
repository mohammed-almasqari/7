
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Search, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { TicketStatus } from '@/types/ticket';

export const TicketTracking = () => {
  const { toast } = useToast();
  const [ticketId, setTicketId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [ticketStatus, setTicketStatus] = useState<{
    status: TicketStatus;
    description: string;
  } | null>(null);

  const handleTrackTicket = async () => {
    if (!ticketId.trim()) {
      toast({
        title: "خطأ",
        description: "الرجاء إدخال رقم الطلب",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const statusMap: Record<TicketStatus, string> = {
        new: "طلب جديد - في انتظار المراجعة",
        assigned: "تم تعيين فني - في انتظار الزيارة",
        in_progress: "جاري العمل على الطلب",
        completed: "تم إكمال الطلب",
        cancelled: "تم إلغاء الطلب"
      };
      
      const mockStatus: TicketStatus = "in_progress";
      
      setTicketStatus({
        status: mockStatus,
        description: statusMap[mockStatus]
      });
    } catch (error) {
      toast({
        title: "خطأ في النظام",
        description: "حدث خطأ أثناء جلب حالة الطلب. الرجاء المحاولة مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadgeColor = (status: TicketStatus) => {
    const colors = {
      new: "bg-blue-500",
      assigned: "bg-yellow-500",
      in_progress: "bg-primary",
      completed: "bg-green-500",
      cancelled: "bg-red-500"
    };
    return colors[status];
  };

  return (
    <section className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">تتبع طلب الصيانة</h2>
            <p className="text-muted-foreground">أدخل رقم الطلب لمعرفة حالته</p>
          </div>
          
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ticketId">رقم الطلب</Label>
                  <div className="flex gap-2">
                    <Input
                      id="ticketId"
                      placeholder="مثال: #123456"
                      value={ticketId}
                      onChange={(e) => setTicketId(e.target.value)}
                    />
                    <Button
                      onClick={handleTrackTicket}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4" />
                      )}
                      <span className="mr-2">تتبع</span>
                    </Button>
                  </div>
                </div>

                {ticketStatus && (
                  <div className="bg-background p-4 rounded-lg space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusBadgeColor(ticketStatus.status)}>
                        حالة الطلب
                      </Badge>
                    </div>
                    <p className="text-lg font-medium">{ticketStatus.description}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
