
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, Clock, Zap, Droplet } from 'lucide-react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard = ({ icon, title, description }: FeatureCardProps) => {
  return (
    <Card className="text-center p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
      <CardContent className="pt-6">
        <div className="mb-4 flex justify-center">{icon}</div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

export const FeaturesSection = () => {
  return (
    <section id="features" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">مميزات النظام</h2>
          <p className="text-muted-foreground">كل ما تحتاجه لإدارة صيانة فلاتر المياه في مكان واحد</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard
            icon={<Shield className="w-10 h-10 text-primary" />}
            title="ضمان الجودة"
            description="تقارير فنية معتمدة وضمان شامل على جميع خدمات الصيانة"
          />
          <FeatureCard
            icon={<Clock className="w-10 h-10 text-primary" />}
            title="حجز سريع"
            description="احجز موعد الصيانة في أقل من دقيقة واختر الوقت المناسب لك"
          />
          <FeatureCard
            icon={<Zap className="w-10 h-10 text-primary" />}
            title="صيانة استباقية"
            description="نظام ذكي يتنبأ بمواعيد الصيانة الدورية قبل حدوث المشاكل"
          />
          <FeatureCard
            icon={<Droplet className="w-10 h-10 text-primary" />}
            title="جودة المياه"
            description="مراقبة مستمرة لجودة المياه وتقارير دورية عن أداء الفلتر"
          />
        </div>
      </div>
    </section>
  );
};
