
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const HeroSection = () => {
  const navigate = useNavigate();

  return (
    <section className="relative bg-gradient-to-b from-primary/10 to-background py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <Badge className="px-4 py-2 mb-6 bg-primary/10 text-primary border-primary/20 animate-fade-in">
            وفر 30% على الصيانة الدورية
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 animate-fade-in">
            نظام صيانة فلاتر المياه الأول في المملكة
          </h1>
          <p className="text-xl text-muted-foreground mb-8 animate-fade-in">
            نقدم خدمات صيانة احترافية لفلاتر المياه مع تقارير فنية معتمدة وضمان الجودة
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Button 
              size="lg" 
              className="text-lg"
              onClick={() => navigate('/login')}
            >
              ابدأ الآن
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg"
              onClick={() => document.getElementById('stats')?.scrollIntoView({ behavior: 'smooth' })}
            >
              تعرف على الإحصائيات
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
