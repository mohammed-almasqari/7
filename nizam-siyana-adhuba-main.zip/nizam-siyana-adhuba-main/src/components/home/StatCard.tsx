
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  trend: 'up' | 'down';
  icon: React.ElementType;
  trendValue: string;
}

export const StatCard = ({ title, value, trend, icon: Icon, trendValue }: StatCardProps) => (
  <Card className="hover:shadow-lg transition-shadow duration-200">
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium text-muted-foreground">
        {title}
      </CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      <div className="flex items-center pt-1">
        <TrendingUp className={`h-4 w-4 ${trend === 'up' ? 'text-green-500' : 'text-red-500'}`} />
        <span className={`text-xs ${trend === 'up' ? 'text-green-500' : 'text-red-500'} mr-1`}>
          {trendValue}
        </span>
      </div>
    </CardContent>
  </Card>
);
