
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Users, Wrench, Clock, CheckCircle2 } from 'lucide-react';

export const QuickStats = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <Card className="hover:shadow-lg transition-all duration-300">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">عدد العملاء</p>
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-bold">1,234</h3>
                <span className="text-xs text-green-500">+12.5%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-all duration-300">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-green-500/20 to-green-600/20 rounded-lg">
              <Wrench className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">طلبات الصيانة</p>
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-bold">856</h3>
                <span className="text-xs text-green-500">+8.2%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-all duration-300">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-orange-500/20 to-orange-600/20 rounded-lg">
              <Clock className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">معدل الاستجابة</p>
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-bold">15 دقيقة</h3>
                <span className="text-xs text-red-500">-23.4%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-all duration-300">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-lg">
              <CheckCircle2 className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">رضا العملاء</p>
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-bold">94%</h3>
                <span className="text-xs text-green-500">+2.1%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
