
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Medal } from 'lucide-react';

type LoyaltyProgramCardProps = {
  pointsEarned: number;
  onShowDetails: () => void;
};

export const LoyaltyProgramCard = ({ pointsEarned, onShowDetails }: LoyaltyProgramCardProps) => {
  return (
    <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onShowDetails}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Medal className="w-5 h-5 text-primary" />
          <CardTitle>برنامج الولاء</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{pointsEarned}</div>
        <p className="text-sm text-muted-foreground">نقطة مكتسبة</p>
      </CardContent>
    </Card>
  );
};
