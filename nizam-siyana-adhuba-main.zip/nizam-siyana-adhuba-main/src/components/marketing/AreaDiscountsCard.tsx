
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Target } from 'lucide-react';

type AreaDiscountsCardProps = {
  discountCount: number;
  onShowDetails: () => void;
};

export const AreaDiscountsCard = ({ discountCount, onShowDetails }: AreaDiscountsCardProps) => {
  return (
    <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onShowDetails}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          <CardTitle>خصومات المناطق</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{discountCount}</div>
        <p className="text-sm text-muted-foreground">خصم نشط</p>
      </CardContent>
    </Card>
  );
};
