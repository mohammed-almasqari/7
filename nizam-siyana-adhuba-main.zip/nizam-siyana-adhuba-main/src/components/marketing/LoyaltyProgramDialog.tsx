
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

type LoyaltyProgramDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  program: {
    pointsEarned: number;
    pointsNeeded: number;
    availableRewards: Array<{
      name: string;
      points: number;
      description: string;
    }>;
  };
  onRedeemPoints: (points: number) => void;
};

export const LoyaltyProgramDialog = ({
  open,
  onOpenChange,
  program,
  onRedeemPoints,
}: LoyaltyProgramDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>برنامج الولاء</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="flex justify-between items-center p-4 bg-primary/5 rounded-lg">
            <div>
              <div className="text-sm text-muted-foreground">النقاط المكتسبة</div>
              <div className="text-2xl font-bold">{program.pointsEarned}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">النقاط المطلوبة</div>
              <div className="text-2xl font-bold">{program.pointsNeeded}</div>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {program.availableRewards.map((reward, index) => (
              <Card key={index} className="p-4">
                <h3 className="font-bold mb-2">{reward.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{reward.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm">{reward.points} نقطة</span>
                  <Button
                    onClick={() => onRedeemPoints(reward.points)}
                    disabled={program.pointsEarned < reward.points}
                  >
                    استبدال
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
