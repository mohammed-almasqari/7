
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Target } from 'lucide-react';

type AreaDiscountsDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  discounts: Array<{
    areaName: string;
    discountPercentage: number;
    validUntil: string;
    minimumPurchase?: number;
    servicesIncluded: string[];
  }>;
};

export const AreaDiscountsDialog = ({
  open,
  onOpenChange,
  discounts,
}: AreaDiscountsDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>خصومات المناطق</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4">
          {discounts.map((discount, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-primary" />
                <h3 className="font-bold">{discount.areaName}</h3>
              </div>
              <div className="grid gap-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">نسبة الخصم</span>
                  <span className="font-bold">{discount.discountPercentage}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">صالح حتى</span>
                  <span>{discount.validUntil}</span>
                </div>
                {discount.minimumPurchase && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الحد الأدنى للشراء</span>
                    <span>{discount.minimumPurchase} ريال</span>
                  </div>
                )}
                <div className="mt-2">
                  <span className="text-muted-foreground">الخدمات المشمولة:</span>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {discount.servicesIncluded.map((service, i) => (
                      <span key={i} className="text-sm bg-primary/10 px-2 py-1 rounded">
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};
