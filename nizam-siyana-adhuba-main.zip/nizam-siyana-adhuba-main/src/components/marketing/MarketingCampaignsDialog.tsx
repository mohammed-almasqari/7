
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Calendar, Target, Coins } from 'lucide-react';
import type { MarketingCampaign } from '@/types/marketing';

type MarketingCampaignsDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  campaigns: MarketingCampaign[];
};

export const MarketingCampaignsDialog = ({
  open,
  onOpenChange,
  campaigns,
}: MarketingCampaignsDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>الحملات التسويقية</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4">
          {campaigns.map((campaign) => (
            <Card key={campaign.id} className="p-4">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-lg">{campaign.name}</h3>
                <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                  {campaign.status === 'active' ? 'نشطة' : 'مجدولة'}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-4">{campaign.description}</p>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{campaign.targetAudience}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{campaign.startDate} - {campaign.endDate}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{campaign.targetArea}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{campaign.budget} ريال</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};
