
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import {
  LayoutDashboard,
  Users,
  Wrench,
  Package,
  Map,
  Brain,
  Plug,
  Settings,
  FileText,
  CircleDollarSign,
  Building2,
  Calendar,
  Bell,
  MessageSquare,
  TicketCheck,
  Megaphone,
} from "lucide-react";

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function MainSidebar({ className }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const adminItems = [
    {
      title: "لوحة التحكم",
      icon: <LayoutDashboard className="h-4 w-4" />,
      href: "/admin",
    },
    {
      title: "نظرة عامة",
      icon: <LayoutDashboard className="h-4 w-4" />,
      href: "/admin/overview",
    },
    {
      title: "التسويق",
      icon: <Megaphone className="h-4 w-4" />,
      href: "/admin/marketing",
    },
    {
      title: "الفنيين",
      icon: <Users className="h-4 w-4" />,
      href: "/admin/technicians",
    },
    {
      title: "طلبات الصيانة",
      icon: <Wrench className="h-4 w-4" />,
      href: "/admin/maintenance",
    },
    {
      title: "المخزون",
      icon: <Package className="h-4 w-4" />,
      href: "/admin/inventory",
    },
    {
      title: "العملاء",
      icon: <Users className="h-4 w-4" />,
      href: "/admin/customers",
    },
    {
      title: "التغطية",
      icon: <Map className="h-4 w-4" />,
      href: "/admin/coverage",
    },
    {
      title: "الذكاء الاصطناعي",
      icon: <Brain className="h-4 w-4" />,
      href: "/admin/ai",
    },
    {
      title: "التكامل",
      icon: <Plug className="h-4 w-4" />,
      href: "/admin/integration",
    },
    {
      title: "التقارير",
      icon: <FileText className="h-4 w-4" />,
      href: "/admin/reports",
    },
    {
      title: "المالية",
      icon: <CircleDollarSign className="h-4 w-4" />,
      href: "/admin/finance",
    },
    {
      title: "الشركات",
      icon: <Building2 className="h-4 w-4" />,
      href: "/admin/companies",
    },
    {
      title: "الجدولة",
      icon: <Calendar className="h-4 w-4" />,
      href: "/admin/scheduling",
    },
    {
      title: "الإشعارات",
      icon: <Bell className="h-4 w-4" />,
      href: "/admin/notifications",
    },
    {
      title: "التذاكر",
      icon: <TicketCheck className="h-4 w-4" />,
      href: "/admin/tickets",
    },
    {
      title: "المراسلات",
      icon: <MessageSquare className="h-4 w-4" />,
      href: "/admin/messages",
    },
    {
      title: "الإعدادات",
      icon: <Settings className="h-4 w-4" />,
      href: "/admin/settings",
    },
  ];

  if (!user) return null;

  return (
    <div className={cn("pb-12", className)}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
            القائمة الرئيسية
          </h2>
          <ScrollArea className="h-[calc(100vh-10rem)] px-2">
            <div className="space-y-1">
              {adminItems.map((item, index) => (
                <Button
                  key={index}
                  variant={location.pathname === item.href ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => navigate(item.href)}
                >
                  {item.icon}
                  <span className="mr-2">{item.title}</span>
                </Button>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
