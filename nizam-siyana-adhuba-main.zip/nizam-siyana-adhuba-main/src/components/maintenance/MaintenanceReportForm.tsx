
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from "@/contexts/NotificationsContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  FileSpreadsheet,
  Building,
  AlertCircle,
  BarChart,
  Star,
  DollarSign,
  UserCheck,
  FileText,
} from 'lucide-react';

interface WaterQualityData {
  tdsInput: number;
  tdsOutput: number;
  ph: number;
  pressure: number;
}

interface SparePart {
  name: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  stockId?: string;
}

interface MaintenanceReport {
  id?: string;
  deviceId: string;
  technicianId: string;
  date: string;
  waterQuality: WaterQualityData;
  spareParts: SparePart[];
  laborCost: number;
  totalCost: number;
  notes?: string;
  status: 'draft' | 'submitted' | 'approved' | 'completed';
}

interface TechnicianPerformance {
  id: string;
  name: string;
  completedJobs: number;
  rating: number;
  efficiency: number;
  specialties: string[];
  responseTime: number;
}

interface CostAnalysis {
  category: string;
  amount: number;
  percentage: number;
  trend: 'up' | 'down' | 'stable';
}

interface DetailedCustomerReport {
  deviceId: string;
  maintenanceHistory: {
    date: string;
    type: string;
    cost: number;
    technician: string;
    status: string;
  }[];
  totalSpent: number;
  nextScheduledMaintenance?: string;
}

export const MaintenanceReportForm = () => {
  const { toast } = useToast();
  const { sendNotification } = useNotifications();
  const [showCostAnalysis, setShowCostAnalysis] = useState(false);
  const [showTechnicianPerformance, setShowTechnicianPerformance] = useState(false);
  const [showDetailedReport, setShowDetailedReport] = useState(false);

  const mockCostData: CostAnalysis[] = [
    { category: "قطع الغيار", amount: 15000, percentage: 45, trend: "up" },
    { category: "العمالة", amount: 8000, percentage: 25, trend: "stable" },
    { category: "المعدات", amount: 6000, percentage: 20, trend: "down" },
    { category: "النقل", amount: 3000, percentage: 10, trend: "stable" }
  ];

  const mockTechnicianData: TechnicianPerformance[] = [
    {
      id: "1",
      name: "أحمد محمد",
      completedJobs: 150,
      rating: 4.8,
      efficiency: 92,
      specialties: ["تنقية المياه", "صيانة المضخات"],
      responseTime: 25
    },
    {
      id: "2",
      name: "خالد عبدالله",
      completedJobs: 120,
      rating: 4.6,
      efficiency: 88,
      specialties: ["معالجة المياه", "تركيب الفلاتر"],
      responseTime: 30
    }
  ];

  const mockCustomerReport: DetailedCustomerReport = {
    deviceId: "dev_001",
    maintenanceHistory: [
      {
        date: "2024-03-15",
        type: "صيانة دورية",
        cost: 500,
        technician: "أحمد محمد",
        status: "مكتمل"
      },
      {
        date: "2024-02-15",
        type: "إصلاح طارئ",
        cost: 800,
        technician: "خالد عبدالله",
        status: "مكتمل"
      }
    ],
    totalSpent: 1300,
    nextScheduledMaintenance: "2024-04-15"
  };

  const handleNotification = (message: string) => {
    sendNotification({
      type: "maintenance_alert",
      data: {
        message,
        priority: "medium",
        reportId: Date.now().toString()
      }
    });

    toast({
      title: "تم بنجاح",
      description: message,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end gap-2 mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowCostAnalysis(true)}
        >
          <DollarSign className="h-4 w-4 ml-2" />
          تحليل التكاليف
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowTechnicianPerformance(true)}
        >
          <UserCheck className="h-4 w-4 ml-2" />
          أداء الفنيين
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowDetailedReport(true)}
        >
          <FileText className="h-4 w-4 ml-2" />
          التقرير التفصيلي
        </Button>
      </div>

      {/* نافذة تحليل التكاليف */}
      <Dialog open={showCostAnalysis} onOpenChange={setShowCostAnalysis}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>تحليل التكاليف والميزانية</DialogTitle>
            <DialogDescription>
              تحليل تفصيلي للتكاليف والمصروفات
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">توزيع التكاليف</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockCostData.map((item) => (
                    <div key={item.category} className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="font-medium">{item.category}</p>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{item.amount} ريال</p>
                        <p className="text-sm text-muted-foreground">{item.percentage}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* نافذة أداء الفنيين */}
      <Dialog open={showTechnicianPerformance} onOpenChange={setShowTechnicianPerformance}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>تقييم أداء الفنيين</DialogTitle>
            <DialogDescription>
              تحليل وتقييم أداء الفنيين
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockTechnicianData.map((tech) => (
              <Card key={tech.id}>
                <CardHeader>
                  <CardTitle className="text-lg">{tech.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <dl className="space-y-2">
                    <div className="flex justify-between">
                      <dt className="text-sm text-muted-foreground">الصيانات المكتملة</dt>
                      <dd className="font-medium">{tech.completedJobs}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm text-muted-foreground">التقييم</dt>
                      <dd className="font-medium">{tech.rating}/5</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm text-muted-foreground">الكفاءة</dt>
                      <dd className="font-medium">{tech.efficiency}%</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm text-muted-foreground">وقت الاستجابة</dt>
                      <dd className="font-medium">{tech.responseTime} دقيقة</dd>
                    </div>
                    <div>
                      <dt className="text-sm text-muted-foreground mb-1">التخصصات</dt>
                      <dd className="flex flex-wrap gap-2">
                        {tech.specialties.map((specialty) => (
                          <Badge key={specialty} variant="secondary">
                            {specialty}
                          </Badge>
                        ))}
                      </dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* نافذة التقرير التفصيلي */}
      <Dialog open={showDetailedReport} onOpenChange={setShowDetailedReport}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>التقرير التفصيلي للعميل</DialogTitle>
            <DialogDescription>
              سجل الصيانة والتكاليف التفصيلي
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h4 className="font-medium">رقم الجهاز: {mockCustomerReport.deviceId}</h4>
              <Badge variant="secondary">
                إجمالي التكاليف: {mockCustomerReport.totalSpent} ريال
              </Badge>
            </div>
            
            {mockCustomerReport.nextScheduledMaintenance && (
              <Card className="bg-muted">
                <CardContent className="p-4">
                  <p className="text-sm">
                    الصيانة القادمة: {new Date(mockCustomerReport.nextScheduledMaintenance).toLocaleDateString('ar-SA')}
                  </p>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {mockCustomerReport.maintenanceHistory.map((record, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <p className="font-medium">{record.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(record.date).toLocaleDateString('ar-SA')}
                        </p>
                        <p className="text-sm">الفني: {record.technician}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline">{record.status}</Badge>
                        <p className="mt-2 font-medium">{record.cost} ريال</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button 
              className="w-full"
              onClick={() => {
                handleNotification("تم تحديث التقرير التفصيلي للعميل");
                setShowDetailedReport(false);
              }}
            >
              تصدير التقرير
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
