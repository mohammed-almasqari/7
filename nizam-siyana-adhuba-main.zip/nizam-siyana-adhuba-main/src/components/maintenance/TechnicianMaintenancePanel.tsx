
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Device, DeviceBranch, getDeviceStatus } from '@/types/device';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Settings,
  AlertTriangle,
  MapPin,
  Activity,
  CheckCircle,
  Clock,
  CircleDollarSign,
  FileSpreadsheet,
} from 'lucide-react';

interface MaintenanceTask {
  id: string;
  deviceId: string;
  branchId: string;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'high' | 'medium' | 'low';
  description: string;
  requestDate: string;
  spareParts?: {
    name: string;
    quantity: number;
    cost: number;
  }[];
}

interface TechnicianMaintenancePanelProps {
  tasks: MaintenanceTask[];
  branches: DeviceBranch[];
  onTaskUpdate: (taskId: string, status: string, report?: any) => void;
}

export const TechnicianMaintenancePanel = ({
  tasks,
  branches,
  onTaskUpdate,
}: TechnicianMaintenancePanelProps) => {
  const { toast } = useToast();
  const [selectedTask, setSelectedTask] = useState<MaintenanceTask | null>(null);
  const [reportData, setReportData] = useState({
    waterQuality: {
      tdsInput: '',
      tdsOutput: '',
      ph: '',
      pressure: '',
    },
    spareParts: [] as { name: string; quantity: number; cost: number }[],
    notes: '',
  });

  const handleTaskCompletion = (task: MaintenanceTask) => {
    onTaskUpdate(task.id, 'completed', reportData);
    toast({
      title: "تم إكمال المهمة",
      description: "تم حفظ التقرير وإرسال الإشعار للعميل",
    });
    setSelectedTask(null);
    setReportData({
      waterQuality: { tdsInput: '', tdsOutput: '', ph: '', pressure: '' },
      spareParts: [],
      notes: '',
    });
  };

  const addSparePart = () => {
    setReportData(prev => ({
      ...prev,
      spareParts: [...prev.spareParts, { name: '', quantity: 1, cost: 0 }],
    }));
  };

  const getDeviceDetails = (deviceId: string, branchId: string) => {
    const branch = branches.find(b => b.id === branchId);
    return branch?.devices.find(d => d.id === deviceId);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-700';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700';
      case 'low':
        return 'bg-green-100 text-green-700';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              الطلبات الجديدة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tasks.filter(t => t.status === 'pending').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              قيد التنفيذ
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tasks.filter(t => t.status === 'in_progress').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              المكتملة اليوم
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tasks.filter(t => t.status === 'completed').length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة المهام</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الموقع</TableHead>
                <TableHead>الجهاز</TableHead>
                <TableHead>الأولوية</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tasks.map((task) => {
                const device = getDeviceDetails(task.deviceId, task.branchId);
                const branch = branches.find(b => b.id === task.branchId);
                return (
                  <TableRow key={task.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {branch?.name}
                      </div>
                    </TableCell>
                    <TableCell>{device?.model}</TableCell>
                    <TableCell>
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority === 'high' ? 'عاجل' : task.priority === 'medium' ? 'متوسط' : 'عادي'}
                      </Badge>
                    </TableCell>
                    <TableCell>{task.status === 'pending' ? 'جديد' : task.status === 'in_progress' ? 'قيد التنفيذ' : 'مكتمل'}</TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedTask(task)}
                      >
                        <Settings className="h-4 w-4 ml-2" />
                        تفاصيل
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {selectedTask && (
        <Card>
          <CardHeader>
            <CardTitle>تقرير الصيانة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">TDS المدخل</label>
                  <Input
                    type="number"
                    value={reportData.waterQuality.tdsInput}
                    onChange={(e) => setReportData(prev => ({
                      ...prev,
                      waterQuality: { ...prev.waterQuality, tdsInput: e.target.value }
                    }))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">TDS المخرج</label>
                  <Input
                    type="number"
                    value={reportData.waterQuality.tdsOutput}
                    onChange={(e) => setReportData(prev => ({
                      ...prev,
                      waterQuality: { ...prev.waterQuality, tdsOutput: e.target.value }
                    }))}
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">قطع الغيار المستخدمة</label>
                {reportData.spareParts.map((part, index) => (
                  <div key={index} className="grid grid-cols-3 gap-2 mt-2">
                    <Input
                      placeholder="اسم القطعة"
                      value={part.name}
                      onChange={(e) => {
                        const newParts = [...reportData.spareParts];
                        newParts[index].name = e.target.value;
                        setReportData(prev => ({ ...prev, spareParts: newParts }));
                      }}
                    />
                    <Input
                      type="number"
                      placeholder="الكمية"
                      value={part.quantity}
                      onChange={(e) => {
                        const newParts = [...reportData.spareParts];
                        newParts[index].quantity = parseInt(e.target.value);
                        setReportData(prev => ({ ...prev, spareParts: newParts }));
                      }}
                    />
                    <Input
                      type="number"
                      placeholder="التكلفة"
                      value={part.cost}
                      onChange={(e) => {
                        const newParts = [...reportData.spareParts];
                        newParts[index].cost = parseFloat(e.target.value);
                        setReportData(prev => ({ ...prev, spareParts: newParts }));
                      }}
                    />
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addSparePart}
                  className="mt-2"
                >
                  إضافة قطعة غيار
                </Button>
              </div>

              <div>
                <label className="text-sm font-medium">ملاحظات</label>
                <Textarea
                  value={reportData.notes}
                  onChange={(e) => setReportData(prev => ({
                    ...prev,
                    notes: e.target.value
                  }))}
                  rows={4}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setSelectedTask(null)}
                >
                  إلغاء
                </Button>
                <Button
                  onClick={() => handleTaskCompletion(selectedTask)}
                >
                  إكمال المهمة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
