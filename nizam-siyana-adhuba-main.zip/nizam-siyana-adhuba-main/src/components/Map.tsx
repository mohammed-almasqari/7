
import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

interface MapProps {
  center: [number, number];
  zoom?: number;
  technicians?: {
    id: string;
    name: string;
    location: [number, number];
    status: 'available' | 'busy' | 'off_duty';
  }[];
}

const Map = ({ center, zoom = 12, technicians = [] }: MapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<{ [key: string]: mapboxgl.Marker }>({});

  useEffect(() => {
    if (!mapContainer.current) return;

    mapboxgl.accessToken = 'pk.eyJ1IjoibW9oYW1tZWQ3MTQiLCJhIjoiY203ZTJnbzhuMDRlazJsc2U3N2I3MDYyNyJ9.MmXwjUOFzL7R2HOxxU0leA';
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: center,
      zoom: zoom,
    });

    // Add navigation controls
    map.current.addControl(
      new mapboxgl.NavigationControl(),
      'top-right'
    );

    return () => {
      Object.values(markers.current).forEach(marker => marker.remove());
      map.current?.remove();
    };
  }, []);

  // Update technician markers
  useEffect(() => {
    if (!map.current) return;

    // Remove old markers
    Object.values(markers.current).forEach(marker => marker.remove());
    markers.current = {};

    // Add new markers
    technicians.forEach(tech => {
      const el = document.createElement('div');
      el.className = 'w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium shadow-lg';
      el.innerHTML = tech.name.charAt(0);
      el.style.backgroundColor = tech.status === 'available' ? '#22c55e' : 
                                tech.status === 'busy' ? '#eab308' : '#94a3b8';

      const popup = new mapboxgl.Popup({ offset: 25 })
        .setHTML(`
          <div class="p-2 text-right">
            <h3 class="font-bold">${tech.name}</h3>
            <p class="text-sm text-gray-600">
              ${tech.status === 'available' ? 'متاح' : 
                tech.status === 'busy' ? 'مشغول' : 'غير متاح'}
            </p>
          </div>
        `);

      const marker = new mapboxgl.Marker({ element: el })
        .setLngLat(tech.location)
        .setPopup(popup)
        .addTo(map.current!);

      markers.current[tech.id] = marker;
    });
  }, [technicians]);

  return (
    <div className="w-full h-96 rounded-lg overflow-hidden shadow-lg">
      <div ref={mapContainer} className="w-full h-full" />
    </div>
  );
};

export default Map;
