
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface LoyaltyTier {
  name: string;
  threshold: number;
  benefits: string[];
}

interface LoyaltyProgramProps {
  currentTier: LoyaltyTier;
  loyaltyPoints: number;
  tiers: LoyaltyTier[];
}

export const LoyaltyProgram = ({ currentTier, loyaltyPoints, tiers }: LoyaltyProgramProps) => {
  const nextTier = tiers.find(tier => tier.threshold > loyaltyPoints);
  const progress = nextTier 
    ? (loyaltyPoints / nextTier.threshold) * 100
    : 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle>برنامج الولاء</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold mb-2">المستوى الحالي: {currentTier.name}</h3>
            <p className="text-sm text-muted-foreground">النقاط: {loyaltyPoints}</p>
          </div>

          {nextTier && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{currentTier.name}</span>
                <span>{nextTier.name}</span>
              </div>
              <Progress value={progress} />
              <p className="text-sm text-muted-foreground">
                {nextTier.threshold - loyaltyPoints} نقطة متبقية للمستوى التالي
              </p>
            </div>
          )}

          <div>
            <h4 className="font-medium mb-2">المزايا الحالية:</h4>
            <ul className="list-disc list-inside space-y-1">
              {currentTier.benefits.map((benefit, index) => (
                <li key={index} className="text-sm">{benefit}</li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
