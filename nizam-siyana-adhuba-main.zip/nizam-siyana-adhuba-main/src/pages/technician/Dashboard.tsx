
import React from 'react';
import { Calendar as CalendarIcon, ClipboardList, Star, Timer, CheckCircle, AlertTriangle, Camera } from 'lucide-react';
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  ResponsiveContainer,
  AreaChart,
  Area 
} from 'recharts';

// بيانات تجريبية - استبدلها بالبيانات الحقيقية من الباك إند
const monthlyStats = [
  { month: "يناير", tasks: 65, avgTime: 45, rating: 4.8 },
  { month: "فبراير", tasks: 75, avgTime: 42, rating: 4.9 },
  { month: "مارس", tasks: 80, avgTime: 38, rating: 4.7 },
  { month: "أبريل", tasks: 70, avgTime: 40, rating: 4.8 },
  { month: "مايو", tasks: 56, avgTime: 42, rating: 4.8 },
  { month: "يونيو", tasks: 55, avgTime: 49, rating: 4.9 },
];

const TechnicianDashboard = () => {
  const [date, setDate] = React.useState<Date | undefined>(new Date());

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">لوحة الفني</h1>

      {/* الإحصائيات السريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="hover:shadow-lg transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-lg">
                <ClipboardList className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مهام اليوم</p>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold">5</h3>
                  <span className="text-xs text-green-500">+2</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-green-500/20 to-green-600/20 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مهام منجزة</p>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold">3/5</h3>
                  <span className="text-xs text-green-500">60%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-orange-500/20 to-orange-600/20 rounded-lg">
                <Timer className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">متوسط وقت الإنجاز</p>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold">45 دقيقة</h3>
                  <span className="text-xs text-green-500">-5%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-yellow-500/20 to-yellow-600/20 rounded-lg">
                <Star className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">تقييم الشهر</p>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold">4.8</h3>
                  <span className="text-xs text-green-500">+0.2</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* قسم التقويم */}
        <Card className="hover:shadow-lg transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-lg">
                <CalendarIcon className="h-5 w-5 text-purple-600" />
              </div>
              <CardTitle>التقويم الذكي</CardTitle>
            </div>
            <CardDescription>جدول المواعيد والمهام</CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
            />
            <div className="mt-4">
              <h4 className="font-bold mb-2">مواعيد اليوم:</h4>
              <div className="space-y-2">
                <Card className="p-2 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/10 dark:to-blue-800/10">
                  <div className="flex items-center justify-between">
                    <span>صيانة فلتر - شارع الملك فهد</span>
                    <span className="text-sm opacity-70">10:00 صباحاً</span>
                  </div>
                </Card>
                <Card className="p-2 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/10 dark:to-green-800/10">
                  <div className="flex items-center justify-between">
                    <span>تغيير قطع غيار - حي الياسمين</span>
                    <span className="text-sm opacity-70">02:30 مساءً</span>
                  </div>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* قسم التقارير */}
        <Card className="hover:shadow-lg transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-br from-indigo-500/20 to-indigo-600/20 rounded-lg">
                <ClipboardList className="h-5 w-5 text-indigo-600" />
              </div>
              <CardTitle>التقارير</CardTitle>
            </div>
            <CardDescription>إدارة تقارير الصيانة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">نوع التقرير</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع التقرير" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="filter">تنظيف فلتر</SelectItem>
                    <SelectItem value="parts">استبدال قطع غيار</SelectItem>
                    <SelectItem value="maintenance">صيانة دورية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Card className="p-4 border border-dashed border-primary/50 text-center cursor-pointer hover:bg-primary/5 transition-colors">
                <Camera className="h-8 w-8 mx-auto mb-2 text-primary/70" />
                <p className="text-sm">التقط صورة أو اسحب الملف هنا</p>
                <p className="text-xs text-muted-foreground mt-1">سيتم تحويل النص تلقائياً باستخدام OCR</p>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* رسم بياني للإحصائيات */}
      <Card className="hover:shadow-lg transition-all duration-300">
        <CardHeader>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-cyan-500/20 to-cyan-600/20 rounded-lg">
              <BarChart className="h-5 w-5 text-cyan-600" />
            </div>
            <CardTitle>إحصائيات الأداء</CardTitle>
          </div>
          <CardDescription>تحليل الأداء الشهري</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyStats}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-50" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="tasks" name="عدد المهام" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="left" dataKey="avgTime" name="متوسط الوقت (دقيقة)" fill="#93c5fd" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="rating" name="التقييم" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TechnicianDashboard;
