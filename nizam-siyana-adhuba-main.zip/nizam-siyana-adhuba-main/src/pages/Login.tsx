
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { LogIn, UserPlus } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

export const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { login, signup } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isLogin) {
        await login(email, password);
        toast({
          title: "تم تسجيل الدخول بنجاح",
          description: "مرحباً بك في نظام صيانة عذوبة",
        });
        navigate('/customer');
      } else {
        if (!name) {
          throw new Error('الرجاء إدخال الاسم');
        }
        await signup(email, password, name);
        toast({
          title: "تم إنشاء الحساب بنجاح",
          description: "يمكنك الآن تسجيل الدخول",
        });
        setIsLogin(true);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: isLogin ? "خطأ في تسجيل الدخول" : "خطأ في إنشاء الحساب",
        description: error instanceof Error ? error.message : "حدث خطأ غير متوقع",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-4 h-10 flex items-center justify-end">
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsLogin(true)}
              className="flex items-center gap-1 text-primary"
            >
              <LogIn className="h-4 w-4" />
              <span>تسجيل الدخول</span>
            </Button>
            <Button 
              variant="default"
              size="sm"
              onClick={() => setIsLogin(false)}
              className="flex items-center gap-1 bg-primary text-white hover:bg-primary/90"
            >
              <UserPlus className="h-4 w-4" />
              <span>إنشاء حساب جديد</span>
            </Button>
          </div>
        </div>
      </div>

      <nav className="sticky top-0 right-0 left-0 z-50 bg-background/80 backdrop-blur-lg border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-center">
          <h1 className="font-cairo text-2xl font-bold text-primary">نظام صيانة عذوبة</h1>
        </div>
      </nav>

      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-2 text-center">
            <CardTitle className="text-2xl font-bold text-primary">
              {isLogin ? 'مرحباً بك مجدداً!' : 'إنشاء حساب جديد'}
            </CardTitle>
            <CardDescription className="text-base">
              {isLogin 
                ? 'قم بتسجيل الدخول للوصول إلى لوحة التحكم'
                : 'أدخل بياناتك لإنشاء حساب جديد'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm">
                    الاسم الكامل
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="أدخل اسمك الكامل"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="h-12"
                    required={!isLogin}
                    disabled={isLoading}
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm">
                  البريد الإلكتروني
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-sm">
                    كلمة المرور
                  </Label>
                  {isLogin && (
                    <Button variant="link" className="text-sm p-0 h-auto">
                      نسيت كلمة المرور؟
                    </Button>
                  )}
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="أدخل كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12"
                  required
                  disabled={isLoading}
                />
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-base"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    {isLogin ? 'جاري تسجيل الدخول...' : 'جاري إنشاء الحساب...'}
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    {isLogin ? (
                      <>
                        <LogIn className="h-5 w-5" />
                        تسجيل الدخول
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-5 w-5" />
                        إنشاء حساب
                      </>
                    )}
                  </span>
                )}
              </Button>

              <div className="text-center text-sm text-muted-foreground">
                {isLogin ? (
                  <>
                    ليس لديك حساب؟{" "}
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-primary"
                      onClick={() => setIsLogin(false)}
                    >
                      إنشاء حساب جديد
                    </Button>
                  </>
                ) : (
                  <>
                    لديك حساب بالفعل؟{" "}
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-primary"
                      onClick={() => setIsLogin(true)}
                    >
                      تسجيل الدخول
                    </Button>
                  </>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Login;
