
import React from 'react';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturesSection } from '@/components/home/FeaturesSection';
import { CTASection } from '@/components/home/CTASection';
import { TicketTracking } from '@/components/home/TicketTracking';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

export const Index = () => {
  const { user } = useAuth();

  // إذا كان المستخدم مسجل دخوله، قم بتوجيهه إلى لوحة التحكم المناسبة
  if (user) {
    switch (user.role) {
      case 'admin':
        return <Navigate to="/admin/dashboard" replace />;
      case 'technician':
        return <Navigate to="/technician/dashboard" replace />;
      case 'customer':
        return <Navigate to="/customer/dashboard" replace />;
      default:
        return <Navigate to="/customer/dashboard" replace />;
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <FeaturesSection />
      <TicketTracking />
      <CTASection />
    </div>
  );
};

export default Index;
