
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Users, CheckCircle } from 'lucide-react';

const Scheduling = () => {
  const appointments = [
    {
      id: "SCH001",
      title: "صيانة دورية",
      customerName: "أحمد محمد",
      location: "الرياض - حي النزهة",
      date: "2024-03-20",
      time: "10:00",
      technician: "محمد العتيبي",
      status: "scheduled"
    },
    {
      id: "SCH002",
      title: "تركيب جهاز جديد",
      customerName: "شركة المياه المتقدمة",
      location: "جدة - المنطقة الصناعية",
      date: "2024-03-21",
      time: "14:30",
      technician: "خالد السعيد",
      status: "confirmed"
    },
    {
      id: "SCH003",
      title: "فحص وصيانة",
      customerName: "سارة العتيبي",
      location: "الدمام - حي النور",
      date: "2024-03-22",
      time: "09:00",
      technician: "عبدالله الحربي",
      status: "pending"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">الجدولة</h2>
          <p className="text-muted-foreground">إدارة المواعيد والزيارات</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">عرض التقويم</Button>
          <Button>إضافة موعد جديد</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {appointments.map((appointment) => (
          <Card key={appointment.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{appointment.title}</CardTitle>
                  <p className="text-sm text-muted-foreground">#{appointment.id}</p>
                </div>
              </div>
              <Badge variant="outline">
                <Clock className="w-4 h-4 mr-2" />
                {appointment.time}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{appointment.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{appointment.technician}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">العميل:</span>
                  <span className="text-sm font-medium">{appointment.customerName}</span>
                </div>
                <Button variant="outline" className="w-full">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  تأكيد الموعد
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Scheduling;
