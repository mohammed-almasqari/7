
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, AlertTriangle, CheckCircle, Clock, Settings } from 'lucide-react';
import { useNotifications } from '@/contexts/NotificationsContext';

const Notifications = () => {
  const { notifications, markAsRead } = useNotifications();

  const notificationTypes = {
    ticket_created: {
      icon: <AlertTriangle className="w-5 h-5" />,
      title: "تذكرة جديدة",
      color: "bg-warning/10"
    },
    ticket_updated: {
      icon: <CheckCircle className="w-5 h-5" />,
      title: "تحديث تذكرة",
      color: "bg-success/10"
    },
    maintenance_alert: {
      icon: <Clock className="w-5 h-5" />,
      title: "تنبيه صيانة",
      color: "bg-primary/10"
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">الإشعارات</h2>
          <p className="text-muted-foreground">إدارة وعرض إشعارات النظام</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            إعدادات الإشعارات
          </Button>
          <Button>تحديد الكل كمقروء</Button>
        </div>
      </div>

      <div className="space-y-4">
        {notifications.map((notification) => (
          <Card 
            key={notification.id} 
            className="hover:bg-muted/50 transition-colors cursor-pointer"
            onClick={() => markAsRead(notification.id)}
          >
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`p-2 rounded-lg ${notificationTypes[notification.type]?.color || 'bg-primary/10'}`}>
                {notificationTypes[notification.type]?.icon || <Bell className="w-5 h-5" />}
              </div>
              <div className="flex-1">
                <h3 className="font-medium">{notificationTypes[notification.type]?.title || 'إشعار'}</h3>
                <p className="text-sm text-muted-foreground">{notification.data.message}</p>
              </div>
              <div className="text-sm text-muted-foreground">
                {new Date(notification.timestamp).toLocaleDateString('ar-SA')}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Notifications;
