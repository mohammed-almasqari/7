
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, TrendingUp, CircleDollarSign, ChartBar, Download, Calendar, Users, Activity } from 'lucide-react';

const Reports = () => {
  const reports = [
    {
      id: "REP001",
      title: "تقرير الأداء الشهري",
      description: "ملخص شامل لأداء الشركة خلال الشهر",
      category: "performance",
      lastGenerated: "2024-03-15",
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: "REP002",
      title: "تقرير المبيعات",
      description: "تحليل المبيعات والإيرادات",
      category: "financial",
      lastGenerated: "2024-03-16",
      icon: <CircleDollarSign className="w-5 h-5" />
    },
    {
      id: "REP003",
      title: "تقرير الصيانة",
      description: "إحصائيات وتحليل طلبات الصيانة",
      category: "maintenance",
      lastGenerated: "2024-03-14",
      icon: <Activity className="w-5 h-5" />
    },
    {
      id: "REP004",
      title: "تقرير العملاء",
      description: "تحليل بيانات وسلوك العملاء",
      category: "customers",
      lastGenerated: "2024-03-15",
      icon: <Users className="w-5 h-5" />
    },
    {
      id: "REP005",
      title: "تقرير المخزون",
      description: "حالة المخزون وحركة القطع",
      category: "inventory",
      lastGenerated: "2024-03-16",
      icon: <ChartBar className="w-5 h-5" />
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">التقارير</h2>
          <p className="text-muted-foreground">إنشاء وتحليل التقارير</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">جدولة التقارير</Button>
          <Button>إنشاء تقرير جديد</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report) => (
          <Card key={report.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                {report.icon}
              </div>
              <div>
                <CardTitle className="text-lg">{report.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{report.description}</p>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">آخر تحديث: {report.lastGenerated}</span>
                </div>
                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  تحميل التقرير
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Reports;
