
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Database, 
  Check,
  AlertTriangle,
  RefreshCw,
  Key,
  Lock,
  Table as TableIcon,
  Shield
} from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/integrations/supabase/client';

const DatabaseIntegration = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [dbStats, setDbStats] = useState({
    tables: 0,
    rows: 0,
    size: '0 MB',
    lastBackup: null as string | null,
    status: 'متصل'
  });

  const refreshStats = async () => {
    setIsLoading(true);
    try {
      // محاكاة جلب إحصائيات قاعدة البيانات
      const { data: tablesData, error: tablesError } = await supabase
        .from('maintenance_tickets')
        .select('count');
      
      if (tablesError) throw tablesError;

      setDbStats({
        tables: 4, // العدد الفعلي من الجداول في النظام
        rows: Number(tablesData[0]?.count || 0),
        size: '2.5 MB',
        lastBackup: new Date().toISOString(),
        status: 'متصل'
      });

      toast({
        title: "تم تحديث الإحصائيات",
        description: "تم تحديث إحصائيات قاعدة البيانات بنجاح",
      });
    } catch (error) {
      console.error('Error refreshing stats:', error);
      toast({
        variant: "destructive",
        title: "خطأ في التحديث",
        description: "حدث خطأ أثناء تحديث إحصائيات قاعدة البيانات",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">تكامل قاعدة البيانات</h2>
          <p className="text-muted-foreground">إدارة اتصال وإعدادات قاعدة البيانات</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={refreshStats}
            disabled={isLoading}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            تحديث الإحصائيات
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">حالة الاتصال</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Badge variant={dbStats.status === 'متصل' ? 'default' : 'destructive'}>
                {dbStats.status}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">عدد الجداول</CardTitle>
            <TableIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dbStats.tables}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">عدد السجلات</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dbStats.rows}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">حجم البيانات</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dbStats.size}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TableIcon className="h-5 w-5" />
              جداول النظام
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الجدول</TableHead>
                  <TableHead>عدد السجلات</TableHead>
                  <TableHead>آخر تحديث</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>maintenance_tickets</TableCell>
                  <TableCell>{dbStats.rows}</TableCell>
                  <TableCell>قبل دقيقة</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>ticket_updates</TableCell>
                  <TableCell>150</TableCell>
                  <TableCell>قبل 5 دقائق</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>maintenance_reports</TableCell>
                  <TableCell>75</TableCell>
                  <TableCell>قبل 10 دقائق</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>system_logs</TableCell>
                  <TableCell>500</TableCell>
                  <TableCell>قبل 2 دقائق</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              معلومات الاتصال
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>عنوان قاعدة البيانات</Label>
              <Input 
                type="text" 
                value="supabase.project.database.url" 
                readOnly 
              />
            </div>
            <div className="space-y-2">
              <Label>المنفذ</Label>
              <Input 
                type="text" 
                value="5432" 
                readOnly 
              />
            </div>
            <div className="space-y-2">
              <Label>اسم قاعدة البيانات</Label>
              <Input 
                type="text" 
                value="maintenance_db" 
                readOnly 
              />
            </div>
            <Alert>
              <Key className="h-4 w-4" />
              <AlertTitle>معلومات الوصول</AlertTitle>
              <AlertDescription>
                يتم إدارة معلومات الوصول تلقائياً من خلال Supabase
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DatabaseIntegration;
