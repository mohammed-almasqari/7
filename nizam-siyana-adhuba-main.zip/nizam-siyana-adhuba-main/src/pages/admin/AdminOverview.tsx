
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  Wrench,
  Clock,
  CheckCircle2,
  AlertTriangle,
  CircleDollarSign,
  Activity,
  MapPin,
  Star,
  ClipboardCheck
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { QuickStats } from '@/components/admin/dashboard/QuickStats';
import { MaintenanceChart } from '@/components/admin/dashboard/MaintenanceChart';
import { RevenueChart } from '@/components/admin/dashboard/RevenueChart';
import { SatisfactionChart } from '@/components/admin/dashboard/SatisfactionChart';

const recentTickets = [
  {
    id: "T-1234",
    customer: "أحمد محمد",
    issue: "تسرب في الفلتر",
    status: "جديد",
    priority: "عالي",
    date: "2024-02-20",
  },
  {
    id: "T-1235",
    customer: "سارة علي",
    issue: "صيانة دورية",
    status: "قيد التنفيذ",
    priority: "متوسط",
    date: "2024-02-19",
  },
  {
    id: "T-1236",
    customer: "محمد أحمد",
    issue: "استبدال فلتر",
    status: "مكتمل",
    priority: "منخفض",
    date: "2024-02-18",
  }
];

const topTechnicians = [
  {
    name: "خالد محمد",
    completedTasks: 45,
    rating: 4.9,
    area: "الرياض الشمالي"
  },
  {
    name: "عبدالله أحمد",
    completedTasks: 38,
    rating: 4.8,
    area: "الرياض الشرقي"
  },
  {
    name: "فهد علي",
    completedTasks: 35,
    rating: 4.7,
    area: "الرياض الغربي"
  }
];

const AdminOverview = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold">لوحة المعلومات</h2>
          <p className="text-muted-foreground mt-1">نظرة عامة على أداء النظام</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Clock className="w-4 h-4 ml-2" />
            آخر تحديث: اليوم 10:30 ص
          </Button>
          <Button>
            <Activity className="w-4 h-4 ml-2" />
            تحديث البيانات
          </Button>
        </div>
      </div>

      <QuickStats />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <MaintenanceChart />
        <RevenueChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-semibold">أحدث طلبات الصيانة</CardTitle>
              <Button variant="ghost" size="sm">عرض الكل</Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] w-full">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الطلب</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>المشكلة</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الأولوية</TableHead>
                    <TableHead>التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="font-medium">{ticket.id}</TableCell>
                      <TableCell>{ticket.customer}</TableCell>
                      <TableCell>{ticket.issue}</TableCell>
                      <TableCell>
                        <Badge variant={
                          ticket.status === "جديد" ? "default" :
                          ticket.status === "قيد التنفيذ" ? "secondary" :
                          "outline"
                        }>
                          {ticket.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={
                          ticket.priority === "عالي" ? "destructive" :
                          ticket.priority === "متوسط" ? "secondary" :
                          "default"
                        }>
                          {ticket.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>{ticket.date}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-semibold">أفضل الفنيين أداءً</CardTitle>
              <Button variant="ghost" size="sm">عرض الكل</Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] w-full">
              <div className="space-y-4">
                {topTechnicians.map((tech, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 space-x-reverse">
                          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                            <Users className="w-6 h-6 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-semibold">{tech.name}</h4>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              {tech.area}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <Star className="w-4 h-4 text-yellow-400" />
                            <span className="font-semibold">{tech.rating}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <ClipboardCheck className="w-4 h-4" />
                            {tech.completedTasks} مهمة مكتملة
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <div className="mb-8">
        <SatisfactionChart />
      </div>
    </div>
  );
};

export default AdminOverview;
