
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, Package, MapPin, CircleDollarSign, CheckCircle, Clock } from 'lucide-react';

const Companies = () => {
  const companies = [
    {
      id: "COM001",
      name: "شركة المياه المتقدمة",
      type: "enterprise",
      employeesCount: 500,
      devicesCount: 50,
      location: "الرياض - المنطقة الصناعية",
      subscription: "premium",
      status: "active"
    },
    {
      id: "COM002",
      name: "مجموعة الصحة والنقاء",
      type: "medium",
      employeesCount: 150,
      devicesCount: 20,
      location: "جدة - المنطقة الصناعية",
      subscription: "standard",
      status: "active"
    },
    {
      id: "COM003",
      name: "مؤسسة المياه النقية",
      type: "small",
      employeesCount: 45,
      devicesCount: 8,
      location: "الدمام - حي النور",
      subscription: "basic",
      status: "active"
    }
  ];

  const getSubscriptionBadge = (subscription: string) => {
    switch (subscription) {
      case 'premium':
        return <Badge variant="default">باقة متقدمة</Badge>;
      case 'standard':
        return <Badge variant="secondary">باقة قياسية</Badge>;
      default:
        return <Badge variant="outline">باقة أساسية</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">الشركات</h2>
          <p className="text-muted-foreground">إدارة حسابات الشركات والمؤسسات</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">تصفية النتائج</Button>
          <Button>إضافة شركة جديدة</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              إجمالي الشركات
            </CardTitle>
            <Building2 className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">25</div>
            <p className="text-xs text-muted-foreground">
              +3 شركات هذا الشهر
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              إجمالي الأجهزة
            </CardTitle>
            <Package className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">342</div>
            <p className="text-xs text-muted-foreground">
              في جميع الشركات
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              معدل الاشتراكات
            </CardTitle>
            <CircleDollarSign className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5,420 ريال</div>
            <p className="text-xs text-muted-foreground">
              متوسط قيمة الاشتراك الشهري
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {companies.map((company) => (
          <Card key={company.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{company.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">#{company.id}</p>
                </div>
              </div>
              {getSubscriptionBadge(company.subscription)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{company.location}</span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{company.employeesCount} موظف</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{company.devicesCount} جهاز</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  عرض التفاصيل
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Companies;
