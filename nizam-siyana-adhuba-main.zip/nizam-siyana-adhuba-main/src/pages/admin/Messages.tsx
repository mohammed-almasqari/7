
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, User, Clock, Search } from 'lucide-react';
import { Input } from "@/components/ui/input";

const Messages = () => {
  const messages = [
    {
      id: "MSG001",
      sender: "أحمد محمد",
      role: "customer",
      content: "متى موعد الصيانة القادم؟",
      timestamp: "2024-03-16 10:30",
      status: "unread"
    },
    {
      id: "MSG002",
      sender: "محمد العتيبي",
      role: "technician",
      content: "تم الانتهاء من الصيانة الدورية",
      timestamp: "2024-03-16 09:45",
      status: "read"
    },
    {
      id: "MSG003",
      sender: "شركة المياه المتقدمة",
      role: "company",
      content: "نحتاج إلى جدولة صيانة للأجهزة",
      timestamp: "2024-03-15 15:20",
      status: "read"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">المراسلات</h2>
          <p className="text-muted-foreground">إدارة المراسلات والرسائل</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">تصفية الرسائل</Button>
          <Button>رسالة جديدة</Button>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="البحث في المراسلات..."
            className="pl-10"
          />
        </div>
      </div>

      <div className="space-y-4">
        {messages.map((message) => (
          <Card 
            key={message.id} 
            className={`hover:bg-muted/50 transition-colors cursor-pointer ${
              message.status === 'unread' ? 'border-primary' : ''
            }`}
          >
            <CardContent className="flex items-center gap-4 p-4">
              <div className="p-2 bg-primary/10 rounded-full">
                <User className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{message.sender}</h3>
                  {message.status === 'unread' && (
                    <Badge variant="default">جديد</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{message.content}</p>
              </div>
              <div className="text-sm text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" />
                {message.timestamp}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Messages;
