
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings as SettingsIcon, Bell, Shield, Users, Globe, Mail, Database, Moon } from 'lucide-react';
import { useTheme } from '@/hooks/use-theme';

const Settings = () => {
  const { theme, toggleTheme } = useTheme();

  const settingsGroups = [
    {
      id: "general",
      title: "الإعدادات العامة",
      icon: <SettingsIcon className="w-5 h-5" />,
      settings: [
        {
          id: "dark-mode",
          name: "الوضع الليلي",
          description: "تفعيل المظهر الداكن للنظام",
          value: theme === 'dark',
          onChange: toggleTheme
        },
        {
          id: "lang",
          name: "اللغة",
          description: "العربية هي اللغة الافتراضية",
          value: true,
          onChange: () => {}
        }
      ]
    },
    {
      id: "notifications",
      title: "إعدادات الإشعارات",
      icon: <Bell className="w-5 h-5" />,
      settings: [
        {
          id: "email-notifications",
          name: "إشعارات البريد",
          description: "استلام الإشعارات عبر البريد الإلكتروني",
          value: true,
          onChange: () => {}
        },
        {
          id: "maintenance-alerts",
          name: "تنبيهات الصيانة",
          description: "إشعارات تذكير مواعيد الصيانة",
          value: true,
          onChange: () => {}
        }
      ]
    },
    {
      id: "security",
      title: "الأمان والخصوصية",
      icon: <Shield className="w-5 h-5" />,
      settings: [
        {
          id: "two-factor",
          name: "التحقق بخطوتين",
          description: "تفعيل التحقق بخطوتين لتسجيل الدخول",
          value: false,
          onChange: () => {}
        },
        {
          id: "activity-log",
          name: "سجل النشاطات",
          description: "تسجيل جميع النشاطات في النظام",
          value: true,
          onChange: () => {}
        }
      ]
    },
    {
      id: "system",
      title: "إعدادات النظام",
      icon: <Database className="w-5 h-5" />,
      settings: [
        {
          id: "backup",
          name: "النسخ الاحتياطي التلقائي",
          description: "إنشاء نسخة احتياطية يومياً",
          value: true,
          onChange: () => {}
        },
        {
          id: "analytics",
          name: "تحليلات النظام",
          description: "جمع بيانات تحليلية لتحسين الأداء",
          value: true,
          onChange: () => {}
        }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">الإعدادات</h2>
          <p className="text-muted-foreground">تخصيص وإدارة إعدادات النظام</p>
        </div>
        <Button variant="outline">استعادة الإعدادات الافتراضية</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {settingsGroups.map((group) => (
          <Card key={group.id}>
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                {group.icon}
              </div>
              <CardTitle>{group.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {group.settings.map((setting) => (
                  <div key={setting.id} className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label htmlFor={setting.id}>{setting.name}</Label>
                      <p className="text-sm text-muted-foreground">
                        {setting.description}
                      </p>
                    </div>
                    <Switch
                      id={setting.id}
                      checked={setting.value}
                      onCheckedChange={setting.onChange}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Settings;
