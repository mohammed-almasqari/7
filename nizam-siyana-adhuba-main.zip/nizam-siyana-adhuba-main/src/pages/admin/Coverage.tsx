
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, Wrench, CheckCircle, AlertTriangle } from 'lucide-react';

const Coverage = () => {
  const areas = [
    {
      id: "AREA001",
      name: "حي النرجس",
      city: "الرياض",
      customersCount: 234,
      techniciansCount: 3,
      activeRequests: 5,
      status: "active"
    },
    {
      id: "AREA002",
      name: "حي الملقا",
      city: "الرياض",
      customersCount: 189,
      techniciansCount: 2,
      activeRequests: 8,
      status: "warning"
    },
    {
      id: "AREA003",
      name: "حي الياسمين",
      city: "الرياض",
      customersCount: 156,
      techniciansCount: 2,
      activeRequests: 3,
      status: "active"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'warning':
        return <Badge variant="destructive" className="flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" /> يحتاج اهتمام
        </Badge>;
      default:
        return <Badge variant="default" className="flex items-center gap-1">
          <CheckCircle className="w-3 h-3" /> نشط
        </Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">مناطق التغطية</h2>
          <p className="text-muted-foreground">إدارة وتنظيم مناطق تقديم الخدمة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">عرض الخريطة</Button>
          <Button>إضافة منطقة جديدة</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {areas.map((area) => (
          <Card key={area.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{area.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{area.city}</p>
                </div>
              </div>
              {getStatusBadge(area.status)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">العملاء</span>
                  </div>
                  <Badge variant="outline">{area.customersCount}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">الفنيين</span>
                  </div>
                  <Badge variant="outline">{area.techniciansCount}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">الطلبات النشطة</span>
                  </div>
                  <Badge variant="outline">{area.activeRequests}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Coverage;
