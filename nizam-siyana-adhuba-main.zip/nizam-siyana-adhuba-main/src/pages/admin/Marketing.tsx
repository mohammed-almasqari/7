import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/components/ui/use-toast';
import { 
  TrendingUp, Users, Target, Calendar, Medal, 
  CheckCircle2, Clock, Megaphone, Gift, ChartBar 
} from 'lucide-react';
import { LoyaltyProgramCard } from '@/components/marketing/LoyaltyProgramCard';
import { LoyaltyProgramDialog } from '@/components/marketing/LoyaltyProgramDialog';
import { AreaDiscountsCard } from '@/components/marketing/AreaDiscountsCard';
import { AreaDiscountsDialog } from '@/components/marketing/AreaDiscountsDialog';
import { MarketingCampaignsCard } from '@/components/marketing/MarketingCampaignsCard';
import { MarketingCampaignsDialog } from '@/components/marketing/MarketingCampaignsDialog';

const Marketing = () => {
  const { toast } = useToast();
  const [showLoyaltyDialog, setShowLoyaltyDialog] = useState(false);
  const [showAreaDiscountsDialog, setShowAreaDiscountsDialog] = useState(false);
  const [showCampaignsDialog, setShowCampaignsDialog] = useState(false);

  const areaDiscounts = [
    {
      areaName: "الرياض",
      discountPercentage: 15,
      validUntil: "2024-06-30",
      minimumPurchase: 500,
      servicesIncluded: ["تركيب", "صيانة", "استبدال"]
    },
    {
      areaName: "جدة",
      discountPercentage: 10,
      validUntil: "2024-05-31",
      servicesIncluded: ["تركيب", "صيانة"]
    },
    {
      areaName: "الدمام",
      discountPercentage: 20,
      validUntil: "2024-07-31",
      minimumPurchase: 750,
      servicesIncluded: ["تركيب", "صيانة", "ترقية"]
    }
  ];

  const campaigns = [
    {
      id: "CAM001",
      name: "حملة الصيف",
      platform: "إنستجرام",
      targetArea: "المنطقة الوسطى",
      budget: 5000,
      duration: "3 أشهر",
      type: "seasonal",
      startDate: "2024-06-01",
      endDate: "2024-08-31",
      targetAudience: "العملاء السكنيين",
      reach: 5000,
      status: "active" as const,
      description: "عروض خاصة على أجهزة تنقية المياه خلال فصل الصيف",
      engagement: 2500
    },
    {
      id: "CAM002",
      name: "عروض الشركات",
      platform: "لينكد إن",
      targetArea: "جميع المناطق",
      budget: 8000,
      duration: "1 شهر",
      type: "business",
      startDate: "2024-04-01",
      endDate: "2024-04-30",
      targetAudience: "الشركات والمؤسسات",
      reach: 1200,
      status: "scheduled" as const,
      description: "باقات خاصة للشركات تشمل التركيب والصيانة",
      engagement: 800
    },
    {
      id: "CAM003",
      name: "برنامج الولاء",
      platform: "تطبيق الشركة",
      targetArea: "جميع المناطق",
      budget: 10000,
      duration: "12 شهر",
      type: "loyalty",
      startDate: "2024-03-01",
      endDate: "2024-12-31",
      targetAudience: "جميع العملاء",
      reach: 3500,
      status: "active" as const,
      description: "برنامج مكافآت ونقاط للعملاء المميزين",
      engagement: 1500
    }
  ];

  const loyaltyProgram = {
    pointsEarned: 2500,
    pointsNeeded: 5000,
    availableRewards: [
      {
        name: "خصم 100 ريال",
        points: 1000,
        description: "خصم فوري على الصيانة القادمة"
      },
      {
        name: "صيانة مجانية",
        points: 3000,
        description: "زيارة صيانة مجانية شاملة"
      },
      {
        name: "ترقية الفلتر",
        points: 5000,
        description: "ترقية مجانية لفلتر أحدث"
      }
    ]
  };

  const handleRedeemPoints = (points: number) => {
    toast({
      title: "تم استبدال النقاط بنجاح",
      description: `تم خصم ${points} نقطة من رصيدك`,
    });
    setShowLoyaltyDialog(false);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold">التسويق</h2>
          <p className="text-muted-foreground mt-2">إدارة الحملات التسويقية والعروض</p>
        </div>
        <Button className="gap-2">
          <Megaphone className="w-4 h-4" />
          إنشاء حملة جديدة
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="campaigns">الحملات</TabsTrigger>
          <TabsTrigger value="loyalty">برنامج الولاء</TabsTrigger>
          <TabsTrigger value="analytics">التحليلات</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MarketingCampaignsCard
              campaignCount={5}
              onShowDetails={() => setShowCampaignsDialog(true)}
            />
            <LoyaltyProgramCard
              pointsEarned={loyaltyProgram.pointsEarned}
              onShowDetails={() => setShowLoyaltyDialog(true)}
            />
            <AreaDiscountsCard
              discountCount={3}
              onShowDetails={() => setShowAreaDiscountsDialog(true)}
            />
          </div>
        </TabsContent>

        <TabsContent value="campaigns">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {campaigns.map((campaign) => (
              <Card key={campaign.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{campaign.name}</CardTitle>
                    <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                      {campaign.status === 'active' ? 'نشطة' : 'مجدولة'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">{campaign.description}</p>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{campaign.targetAudience}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        {campaign.startDate} - {campaign.endDate}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">الوصول:</span>
                      <Badge variant="outline">{campaign.reach} مستخدم</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="loyalty">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>إحصائيات برنامج الولاء</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>العملاء المشاركين</span>
                    <Badge>1,234</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>النقاط الممنوحة</span>
                    <Badge>45,678</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>المكافآت المستبدلة</span>
                    <Badge>789</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>أداء الحملات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  مخطط بياني للحملات
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>تحليل المشاركة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  مخطط تحليل المشاركة
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <LoyaltyProgramDialog
        open={showLoyaltyDialog}
        onOpenChange={setShowLoyaltyDialog}
        program={loyaltyProgram}
        onRedeemPoints={handleRedeemPoints}
      />

      <AreaDiscountsDialog
        open={showAreaDiscountsDialog}
        onOpenChange={setShowAreaDiscountsDialog}
        discounts={areaDiscounts}
      />

      <MarketingCampaignsDialog
        open={showCampaignsDialog}
        onOpenChange={setShowCampaignsDialog}
        campaigns={campaigns}
      />
    </div>
  );
};

export default Marketing;
