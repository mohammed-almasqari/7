
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, AlertTriangle, BarChart, RefreshCcw } from 'lucide-react';

const Inventory = () => {
  const inventory = [
    {
      id: "FLT001",
      name: "فلتر مياه كربوني",
      type: "carbon_filter",
      stock: 45,
      minStock: 20,
      lastUpdated: "2024-03-15",
      status: "in_stock"
    },
    {
      id: "FLT002",
      name: "غشاء التناضح العكسي",
      type: "ro_membrane",
      stock: 15,
      minStock: 25,
      lastUpdated: "2024-03-14",
      status: "low_stock"
    },
    {
      id: "FLT003",
      name: "فلتر الرواسب",
      type: "sediment_filter",
      stock: 60,
      minStock: 30,
      lastUpdated: "2024-03-16",
      status: "in_stock"
    }
  ];

  const getStatusBadge = (status: string, stock: number, minStock: number) => {
    if (status === 'low_stock' || stock <= minStock) {
      return <Badge variant="destructive" className="flex items-center gap-1">
        <AlertTriangle className="w-3 h-3" /> مخزون منخفض
      </Badge>;
    }
    return <Badge variant="default" className="flex items-center gap-1">
      <Package className="w-3 h-3" /> متوفر
    </Badge>;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">إدارة المخزون</h2>
          <p className="text-muted-foreground">متابعة وإدارة قطع الغيار والفلاتر</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">تصدير التقرير</Button>
          <Button>إضافة منتج جديد</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {inventory.map((item) => (
          <Card key={item.id}>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{item.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">رقم المنتج: {item.id}</p>
                </div>
              </div>
              {getStatusBadge(item.status, item.stock, item.minStock)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BarChart className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">المخزون الحالي</span>
                  </div>
                  <span className="text-sm font-medium">{item.stock} قطعة</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">الحد الأدنى</span>
                  </div>
                  <span className="text-sm font-medium">{item.minStock} قطعة</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <RefreshCcw className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">آخر تحديث</span>
                  </div>
                  <span className="text-sm">{item.lastUpdated}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Inventory;
