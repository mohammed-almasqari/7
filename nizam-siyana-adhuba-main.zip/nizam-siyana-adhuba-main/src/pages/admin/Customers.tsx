
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Building2, MapPin, PhoneCall, Calendar, CheckCircle } from 'lucide-react';
import { mockUsers } from '@/data/mockUsers';

const Customers = () => {
  const customers = mockUsers.filter(user => user.role === 'customer');

  const getCustomerTypeBadge = (type?: 'individual' | 'commercial' | 'government') => {
    switch (type) {
      case 'commercial':
        return <Badge variant="secondary">تجاري</Badge>;
      case 'government':
        return <Badge variant="default">حكومي</Badge>;
      default:
        return <Badge variant="outline">أفراد</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">العملاء</h2>
          <p className="text-muted-foreground">إدارة حسابات وبيانات العملاء</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">تصدير البيانات</Button>
          <Button>إضافة عميل جديد</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {customers.map((customer) => (
          <Card key={customer.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  {customer.customerType === 'commercial' ? (
                    <Building2 className="w-5 h-5" />
                  ) : (
                    <User className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <CardTitle className="text-lg">{customer.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">رقم العميل: {customer.id}</p>
                </div>
              </div>
              {getCustomerTypeBadge(customer.customerType)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{customer.phone}</span>
                </div>
                {customer.area && (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{customer.area}</span>
                  </div>
                )}
                {customer.memberSince && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">عضو منذ: {customer.memberSince}</span>
                  </div>
                )}
                {customer.devices && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">الأجهزة المسجلة</span>
                    </div>
                    <Badge variant="outline">{customer.devices.length}</Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Customers;
