import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Wrench,
  User,
  Calendar,
  MapPin,
  Clock,
  CheckCircle,
  XCircle,
  Filter,
  Plus,
  RefreshCw
} from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const MaintenanceRequests = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [requests, setRequests] = useState<any[]>([]);
  const [newRequest, setNewRequest] = useState({
    customerName: '',
    deviceId: '',
    area: '',
    description: '',
    priority: '',
    contactNumber: ''
  });

  const fetchRequests = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('maintenance_tickets')
        .select(`
          *,
          profiles:customer_id(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setRequests(data || []);
      
    } catch (error) {
      console.error('Error fetching requests:', error);
      toast({
        title: "خطأ في تحميل الطلبات",
        description: "حدث خطأ أثناء تحميل طلبات الصيانة",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleRefresh = () => {
    fetchRequests();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="flex items-center gap-1">
          <CheckCircle className="w-3 h-3" /> مكتمل
        </Badge>;
      case 'in_progress':
        return <Badge variant="secondary" className="flex items-center gap-1">
          <Clock className="w-3 h-3" /> قيد التنفيذ
        </Badge>;
      default:
        return <Badge variant="outline" className="flex items-center gap-1">
          <Clock className="w-3 h-3" /> في الانتظار
        </Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="destructive">عالية</Badge>;
      case 'medium':
        return <Badge variant="secondary">متوسطة</Badge>;
      default:
        return <Badge variant="outline">منخفضة</Badge>;
    }
  };

  const handleAssignTechnician = (requestId: string) => {
    toast({
      title: "تعيين فني",
      description: `جاري تعيين فني للطلب رقم ${requestId}`,
    });
  };

  const handleNewRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (!user?.id) {
      toast({
        title: "خطأ في إنشاء الطلب",
        description: "يجب تسجيل الدخول لإنشاء طلب صيانة",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }
    
    try {
      const maintenance_ticket = {
        description: newRequest.description,
        priority: newRequest.priority as 'low' | 'medium' | 'high',
        status: 'new' as const,
        location: {
          address: newRequest.area,
          contact: newRequest.contactNumber
        },
        customer_id: user.id,
        device_id: newRequest.deviceId,
      };

      const { data, error } = await supabase
        .from('maintenance_tickets')
        .insert(maintenance_ticket)
        .select()
        .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      toast({
        title: "تم إنشاء الطلب",
        description: "تم إنشاء طلب الصيانة بنجاح",
      });

      fetchRequests();
      setIsDialogOpen(false);
      
      setNewRequest({
        customerName: '',
        deviceId: '',
        area: '',
        description: '',
        priority: '',
        contactNumber: ''
      });

    } catch (error: any) {
      console.error('Error creating request:', error);
      toast({
        title: "خطأ في إنشاء الطلب",
        description: error.message || "حدث خطأ أثناء محاولة إنشاء طلب الصيانة",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setNewRequest(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">طلبات الصيانة</h2>
          <p className="text-muted-foreground">إدارة ومتابعة طلبات الصيانة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            تصفية النتائج
          </Button>
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isLoading}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            تحديث
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                إضافة طلب جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <form onSubmit={handleNewRequestSubmit}>
                <DialogHeader>
                  <DialogTitle>إنشاء طلب صيانة جديد</DialogTitle>
                  <DialogDescription>
                    قم بإدخال تفاصيل طلب الصيانة الجديد
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="customerName" className="text-right">
                      اسم العميل
                    </Label>
                    <Input
                      id="customerName"
                      value={newRequest.customerName}
                      onChange={(e) => handleInputChange('customerName', e.target.value)}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="deviceId" className="text-right">
                      رقم الجهاز
                    </Label>
                    <Input
                      id="deviceId"
                      value={newRequest.deviceId}
                      onChange={(e) => handleInputChange('deviceId', e.target.value)}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="area" className="text-right">
                      المنطقة
                    </Label>
                    <Input
                      id="area"
                      value={newRequest.area}
                      onChange={(e) => handleInputChange('area', e.target.value)}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="contactNumber" className="text-right">
                      رقم الاتصال
                    </Label>
                    <Input
                      id="contactNumber"
                      value={newRequest.contactNumber}
                      onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                      className="col-span-3"
                      required
                      type="tel"
                      dir="ltr"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="priority" className="text-right">
                      الأولوية
                    </Label>
                    <Select
                      value={newRequest.priority}
                      onValueChange={(value) => handleInputChange('priority', value)}
                      required
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الأولوية" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">عالية</SelectItem>
                        <SelectItem value="medium">متوسطة</SelectItem>
                        <SelectItem value="low">منخفضة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="description" className="text-right">
                      الوصف
                    </Label>
                    <Input
                      id="description"
                      value={newRequest.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      className="col-span-3"
                      required
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? 'جاري الإنشاء...' : 'إنشاء الطلب'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {requests.map((request) => (
          <Card key={request.id} className="hover:bg-muted/50 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">طلب #{request.id.slice(0, 8)}</CardTitle>
                  <p className="text-sm text-muted-foreground">جهاز #{request.device_id}</p>
                </div>
              </div>
              {getStatusBadge(request.status)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{request.profiles?.name || 'غير معروف'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{request.location?.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">
                    تاريخ الطلب: {new Date(request.created_at).toLocaleDateString('ar-SA')}
                    {request.scheduled_for && ` | موعد الصيانة: ${new Date(request.scheduled_for).toLocaleDateString('ar-SA')}`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">الأولوية:</span>
                  {getPriorityBadge(request.priority)}
                </div>
                <div className="bg-muted/50 p-3 rounded-lg">
                  <p className="text-sm">{request.description}</p>
                </div>
                {request.technician_id ? (
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">الفني: {request.technician?.name || 'غير معروف'}</span>
                  </div>
                ) : (
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => handleAssignTechnician(request.id)}
                  >
                    تعيين فني
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default MaintenanceRequests;
