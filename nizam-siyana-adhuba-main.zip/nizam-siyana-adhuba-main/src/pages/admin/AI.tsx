
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, Gauge, Settings, MessageSquare, AlertTriangle, Activity } from 'lucide-react';

const AI = () => {
  const aiFeatures = [
    {
      id: "AI001",
      name: "التنبؤ بالصيانة",
      status: "active",
      accuracy: 92,
      lastUpdate: "منذ 5 دقائق",
      description: "تحليل بيانات الأجهزة للتنبؤ بمواعيد الصيانة المطلوبة"
    },
    {
      id: "AI002",
      name: "تحليل جودة المياه",
      status: "active",
      accuracy: 95,
      lastUpdate: "منذ ساعة",
      description: "مراقبة وتحليل جودة المياه باستخدام الذكاء الاصطناعي"
    },
    {
      id: "AI003",
      name: "توزيع المهام الذكي",
      status: "training",
      accuracy: 85,
      lastUpdate: "منذ يومين",
      description: "توزيع المهام على الفنيين بناءً على الموقع والخبرة"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default" className="flex items-center gap-1">
          <Activity className="w-3 h-3" /> نشط
        </Badge>;
      case 'training':
        return <Badge variant="secondary" className="flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" /> قيد التدريب
        </Badge>;
      default:
        return <Badge variant="outline">معطل</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">الذكاء الاصطناعي</h2>
          <p className="text-muted-foreground">إدارة وتحليل البيانات باستخدام الذكاء الاصطناعي</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">إعدادات النماذج</Button>
          <Button>تدريب نموذج جديد</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              معدل الدقة العام
            </CardTitle>
            <Gauge className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">91%</div>
            <p className="text-xs text-muted-foreground">
              +3.2% من الشهر الماضي
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              نماذج نشطة
            </CardTitle>
            <Brain className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">
              2 قيد التدريب
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              تنبؤات ناجحة
            </CardTitle>
            <Activity className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,250</div>
            <p className="text-xs text-muted-foreground">
              هذا الشهر
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {aiFeatures.map((feature) => (
          <Card key={feature.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Brain className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{feature.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">#{feature.id}</p>
                </div>
              </div>
              {getStatusBadge(feature.status)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">معدل الدقة:</span>
                  <Badge variant="outline">{feature.accuracy}%</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">آخر تحديث:</span>
                  <span className="text-sm">{feature.lastUpdate}</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Settings className="w-4 h-4 mr-2" />
                    الإعدادات
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    التفاصيل
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AI;
