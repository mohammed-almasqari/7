
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, MapPin, PhoneCall, Star, Activity, CheckCircle, XCircle } from 'lucide-react';
import { mockUsers } from '@/data/mockUsers';

const TechnicianManagement = () => {
  const technicians = mockUsers.filter(user => user.role === 'technician');

  const getStatusBadge = (status?: 'available' | 'busy' | 'off_duty') => {
    switch (status) {
      case 'available':
        return <Badge variant="default" className="flex items-center gap-1">
          <CheckCircle className="w-3 h-3" /> متاح
        </Badge>;
      case 'busy':
        return <Badge variant="secondary" className="flex items-center gap-1">
          <XCircle className="w-3 h-3" /> مشغول
        </Badge>;
      default:
        return <Badge variant="destructive" className="flex items-center gap-1">
          <XCircle className="w-3 h-3" /> غير متاح
        </Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">إدارة الفنيين</h2>
          <p className="text-muted-foreground">متابعة وتنظيم فريق الفنيين</p>
        </div>
        <Button>إضافة فني جديد</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {technicians.map((technician) => (
          <Card key={technician.id}>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{technician.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">رقم الموظف: {technician.id}</p>
                </div>
              </div>
              {getStatusBadge(technician.currentStatus)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{technician.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{technician.area}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">المهام المنجزة</span>
                  </div>
                  <Badge variant="outline">{technician.completedJobs || 0}</Badge>
                </div>
                {technician.rating && (
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm">{technician.rating}/5</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default TechnicianManagement;
