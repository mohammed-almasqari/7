
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Ticket, Clock, Users, MessageSquare, AlertTriangle } from 'lucide-react';

const Tickets = () => {
  const tickets = [
    {
      id: "TKT001",
      title: "مشكلة في جهاز التنقية",
      customerName: "أحمد محمد",
      priority: "high",
      status: "open",
      createdAt: "2024-03-15",
      lastUpdate: "2024-03-16",
      description: "جهاز التنقية لا يعمل بشكل صحيح"
    },
    {
      id: "TKT002",
      title: "استفسار عن الصيانة الدورية",
      customerName: "شركة المياه المتقدمة",
      priority: "medium",
      status: "in_progress",
      createdAt: "2024-03-14",
      lastUpdate: "2024-03-15",
      description: "موعد الصيانة القادم"
    },
    {
      id: "TKT003",
      title: "طلب تغيير الفلتر",
      customerName: "سارة العتيبي",
      priority: "low",
      status: "resolved",
      createdAt: "2024-03-13",
      lastUpdate: "2024-03-14",
      description: "الفلتر بحاجة إلى تغيير"
    }
  ];

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="destructive">عالية</Badge>;
      case 'medium':
        return <Badge variant="default">متوسطة</Badge>;
      default:
        return <Badge variant="secondary">منخفضة</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge variant="outline" className="bg-warning/10">مفتوحة</Badge>;
      case 'in_progress':
        return <Badge variant="outline" className="bg-primary/10">قيد المعالجة</Badge>;
      case 'resolved':
        return <Badge variant="outline" className="bg-success/10">تم الحل</Badge>;
      default:
        return <Badge variant="outline">معلقة</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">التذاكر</h2>
          <p className="text-muted-foreground">إدارة تذاكر الدعم والمساعدة</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">تصفية النتائج</Button>
          <Button>إنشاء تذكرة جديدة</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tickets.map((ticket) => (
          <Card key={ticket.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Ticket className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{ticket.title}</CardTitle>
                  <p className="text-sm text-muted-foreground">#{ticket.id}</p>
                </div>
              </div>
              {getPriorityBadge(ticket.priority)}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">{ticket.description}</p>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{ticket.customerName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">آخر تحديث: {ticket.lastUpdate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>{getStatusBadge(ticket.status)}</span>
                  <Button variant="ghost" size="sm">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    الردود
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Tickets;
