
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  RefreshCw, 
  Database, 
  Check, 
  AlertTriangle,
  Settings,
  Upload,
  Download,
  XCircle
} from 'lucide-react';
import { UpdateStatus, SystemVersion, ServerConfig } from '@/types/system';
import { useToast } from '@/hooks/use-toast';
import UpdateService from '@/services/update/UpdateService';

const SystemUpdate = () => {
  const [status, setStatus] = useState<UpdateStatus>({
    isUpdating: false,
    lastUpdate: null,
    currentVersion: null,
    error: null,
    stage: 'idle'
  });

  const { toast } = useToast();

  // تحميل إصدار النظام الحالي عند تحميل الصفحة
  useEffect(() => {
    const loadCurrentVersion = async () => {
      try {
        const version = await UpdateService.getCurrentVersion();
        setStatus(prev => ({ ...prev, currentVersion: version }));
      } catch (error) {
        console.error('فشل في تحميل إصدار النظام:', error);
        toast({
          variant: "destructive",
          title: "خطأ في تحميل إصدار النظام",
          description: "تعذر الحصول على معلومات الإصدار الحالي",
        });
      }
    };

    loadCurrentVersion();
  }, [toast]);

  // مراقبة حالة التحديث
  useEffect(() => {
    let statusInterval: NodeJS.Timeout;

    if (status.isUpdating) {
      statusInterval = setInterval(async () => {
        try {
          const currentStatus = await UpdateService.getUpdateStatus();
          setStatus(prev => ({ ...prev, ...currentStatus }));

          if (currentStatus.stage === 'complete' || currentStatus.stage === 'error') {
            clearInterval(statusInterval);
          }
        } catch (error) {
          console.error('فشل في تحديث الحالة:', error);
          clearInterval(statusInterval);
        }
      }, 3000);
    }

    return () => {
      if (statusInterval) {
        clearInterval(statusInterval);
      }
    };
  }, [status.isUpdating]);

  const getProgress = () => {
    switch (status.stage) {
      case 'backup': return 25;
      case 'sync': return 50;
      case 'verify': return 75;
      case 'complete': return 100;
      case 'error': return 100;
      default: return 0;
    }
  };

  const startUpdate = async () => {
    try {
      setStatus(prev => ({ ...prev, isUpdating: true, stage: 'backup', error: null }));

      // تكوين الخادم - يمكن تحميله من الإعدادات أو طلبه من المستخدم
      const config: ServerConfig = {
        sshHost: 'your-server-host',
        sshUser: 'your-ssh-user',
        sshKeyPath: '~/.ssh/id_rsa',
        repoPath: '/var/www/app',
        backupDir: '/backups'
      };

      await UpdateService.startUpdate(config);

      toast({
        title: "بدأ التحديث",
        description: "جارٍ تحديث النظام...",
      });
    } catch (error) {
      setStatus(prev => ({ 
        ...prev, 
        isUpdating: false, 
        stage: 'error',
        error: error instanceof Error ? error.message : 'حدث خطأ أثناء التحديث'
      }));

      toast({
        variant: "destructive",
        title: "خطأ في التحديث",
        description: "حدث خطأ أثناء بدء عملية التحديث",
      });
    }
  };

  const cancelUpdate = async () => {
    try {
      await UpdateService.cancelUpdate();
      setStatus(prev => ({ ...prev, isUpdating: false, stage: 'idle' }));
      
      toast({
        title: "تم إلغاء التحديث",
        description: "تم إلغاء عملية التحديث بنجاح",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطأ في الإلغاء",
        description: "فشل في إلغاء عملية التحديث",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">تحديث النظام</h2>
          <p className="text-muted-foreground">إدارة تحديثات النظام والنسخ الاحتياطية</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={startUpdate} 
            disabled={status.isUpdating}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${status.isUpdating ? 'animate-spin' : ''}`} />
            تحديث النظام
          </Button>
          {status.isUpdating && (
            <Button 
              variant="destructive" 
              onClick={cancelUpdate}
              className="gap-2"
            >
              <XCircle className="w-4 h-4" />
              إلغاء التحديث
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              نظام التشغيل
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{status.currentVersion?.os || 'غير معروف'}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              إصدار التطبيق
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{status.currentVersion?.app || 'غير معروف'}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              آخر تحديث
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {status.lastUpdate 
                ? new Date(status.lastUpdate).toLocaleDateString('ar-SA')
                : 'لم يتم التحديث بعد'}
            </p>
          </CardContent>
        </Card>
      </div>

      {status.isUpdating && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>حالة التحديث</CardTitle>
            <CardDescription>جارٍ تحديث النظام...</CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={getProgress()} className="mb-2" />
            <p className="text-sm text-muted-foreground">
              {status.stage === 'backup' && 'جارٍ إنشاء نسخة احتياطية...'}
              {status.stage === 'sync' && 'جارٍ مزامنة التحديثات...'}
              {status.stage === 'verify' && 'جارٍ التحقق من سلامة النظام...'}
              {status.stage === 'complete' && 'تم التحديث بنجاح'}
            </p>
          </CardContent>
        </Card>
      )}

      {status.error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>خطأ في التحديث</AlertTitle>
          <AlertDescription>{status.error}</AlertDescription>
        </Alert>
      )}

      {status.stage === 'complete' && !status.error && (
        <Alert>
          <Check className="h-4 w-4" />
          <AlertTitle>تم التحديث بنجاح</AlertTitle>
          <AlertDescription>تم تحديث النظام إلى أحدث إصدار</AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default SystemUpdate;
