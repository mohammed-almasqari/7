import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';
import {
  Users, Settings, FileText, Bell, Calendar, BarChart as BarChartIcon,
  DollarSign, Package, AlertTriangle, Map, Wrench, Brain,
  Activity, CircleDollarSign, UserCog, Building2, ClipboardList,
  MessageSquare, Plug, Megaphone, Target, TrendingUp, RefreshCw
} from 'lucide-react';

const AdminDashboard = () => {
  const navigate = useNavigate();

  const features = [
    {
      title: "نظرة عامة",
      description: "إحصائيات وتحليلات النظام",
      icon: <BarChartIcon className="w-8 h-8" />,
      path: "/admin/overview",
      color: "from-blue-500/20 to-blue-600/20",
      stats: {
        value: "1,234",
        label: "إجمالي العملاء",
        trend: "+12%",
        data: [65, 75, 85, 80, 90, 95],
      }
    },
    {
      title: "التسويق",
      description: "إدارة الحملات التسويقية والعروض",
      icon: <Megaphone className="w-8 h-8" />,
      path: "/admin/marketing",
      color: "from-rose-500/20 to-rose-600/20",
      stats: {
        value: "5",
        label: "حملات نشطة",
        trend: "+2",
        data: [45, 55, 65, 75, 85, 95],
      }
    },
    {
      title: "طلبات الصيانة",
      description: "إدارة وتتبع طلبات الصيانة",
      icon: <Wrench className="w-8 h-8" />,
      path: "/admin/maintenance",
      color: "from-green-500/20 to-green-600/20",
      stats: {
        value: "856",
        label: "طلب نشط",
        trend: "-5%",
        data: [65, 75, 85, 80, 90, 95],
      }
    },
    {
      title: "إدارة الفنيين",
      description: "إدارة وتوزيع المهام على الفنيين",
      icon: <UserCog className="w-8 h-8" />,
      path: "/admin/technicians",
      color: "bg-purple-500/10",
      stats: {
        value: "45",
        label: "فني متاح"
      }
    },
    {
      title: "المخزون",
      description: "إدارة قطع الغيار والفلاتر",
      icon: <Package className="w-8 h-8" />,
      path: "/admin/inventory",
      color: "bg-yellow-500/10",
      stats: {
        value: "1,567",
        label: "قطعة متوفرة"
      }
    },
    {
      title: "التقارير",
      description: "تقارير وإحصائيات الأداء",
      icon: <FileText className="w-8 h-8" />,
      path: "/admin/reports",
      color: "bg-pink-500/10",
      stats: {
        value: "124",
        label: "تقرير هذا الشهر"
      }
    },
    {
      title: "الإشعارات",
      description: "إدارة إشعارات النظام",
      icon: <Bell className="w-8 h-8" />,
      path: "/admin/notifications",
      color: "bg-red-500/10",
      stats: {
        value: "12",
        label: "إشعار جديد"
      }
    },
    {
      title: "الجدولة",
      description: "جدولة المواعيد والزيارات",
      icon: <Calendar className="w-8 h-8" />,
      path: "/admin/scheduling",
      color: "bg-indigo-500/10",
      stats: {
        value: "45",
        label: "موعد اليوم"
      }
    },
    {
      title: "المراسلات",
      description: "إدارة المراسلات والرسائل",
      icon: <MessageSquare className="w-8 h-8" />,
      path: "/admin/messages",
      color: "bg-cyan-500/10",
      stats: {
        value: "28",
        label: "رسالة جديدة"
      }
    },
    {
      title: "الشركات",
      description: "إدارة حسابات الشركات",
      icon: <Building2 className="w-8 h-8" />,
      path: "/admin/companies",
      color: "bg-orange-500/10",
      stats: {
        value: "156",
        label: "شركة نشطة"
      }
    },
    {
      title: "المالية",
      description: "إدارة المدفوعات والفواتير",
      icon: <CircleDollarSign className="w-8 h-8" />,
      path: "/admin/finance",
      color: "bg-emerald-500/10",
      stats: {
        value: "SAR 45K",
        label: "إيرادات اليوم"
      }
    },
    {
      title: "الذكاء الاصطناعي",
      description: "تحليل وتوقعات ذكية",
      icon: <Brain className="w-8 h-8" />,
      path: "/admin/ai",
      color: "bg-violet-500/10",
      stats: {
        value: "89%",
        label: "دقة التوقعات"
      }
    },
    {
      title: "التكامل",
      description: "إدارة التكامل مع الأنظمة",
      icon: <Plug className="w-8 h-8" />,
      path: "/admin/integration",
      color: "bg-teal-500/10",
      stats: {
        value: "8/10",
        label: "أنظمة متصلة"
      }
    },
    {
      title: "تحديث النظام",
      description: "إدارة تحديثات النظام والنسخ الاحتياطية",
      icon: <RefreshCw className="w-8 h-8" />,
      path: "/admin/system-update",
      color: "bg-blue-500/10",
      stats: {
        value: "v1.2.3",
        label: "الإصدار الحالي"
      }
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">لوحة تحكم المدير</h1>
          <p className="text-muted-foreground mt-2">مرحباً بك في نظام إدارة الصيانة</p>
        </div>
        <Button 
          variant="outline" 
          size="lg" 
          className="gap-2"
          onClick={() => navigate('/admin/settings')}
        >
          <Settings className="w-4 h-4" />
          إعدادات النظام
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {features.map((feature, index) => (
          <Card
            key={index}
            className="hover:shadow-lg transition-all duration-300 cursor-pointer group overflow-hidden"
            onClick={() => navigate(feature.path)}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className={`bg-gradient-to-br ${feature.color} p-3 rounded-lg`}>
                  {feature.icon}
                </div>
              </div>
              <h3 className="mt-4 text-xl font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{feature.description}</p>
              <div className="mt-4 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">{feature.stats?.value}</span>
                  <span className="text-sm text-muted-foreground">{feature.stats?.label}</span>
                </div>
                {feature.stats?.trend && (
                  <span className="text-xs text-green-500">{feature.stats.trend}</span>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;
