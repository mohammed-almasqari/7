
import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { CustomerHeader } from '@/components/customer/CustomerHeader';
import { QuickStats } from '@/components/customer/QuickStats';
import { DeviceList } from '@/components/customer/DeviceList';
import { DeviceDetailsDialog } from '@/components/customer/DeviceDetailsDialog';
import { WaterQualityDialog } from '@/components/customer/WaterQualityDialog';
import { LoyaltyProgramCard } from '@/components/marketing/LoyaltyProgramCard';
import { LoyaltyProgramDialog } from '@/components/marketing/LoyaltyProgramDialog';
import type { Device } from '@/data/mockUsers';
import { mockUsers } from '@/data/mockUsers';

// استخراج بيانات العميل التجاري النموذجي
const commercialCustomer = mockUsers.find(user => 
  user.role === 'customer' && 
  user.customerType === 'commercial'
);

const loyaltyProgram = {
  pointsEarned: commercialCustomer?.loyaltyPoints || 0,
  pointsNeeded: 500,
  availableRewards: [
    {
      name: "فلتر مجاني",
      points: 200,
      description: "فلتر مياه عالي الجودة"
    },
    {
      name: "صيانة مجانية",
      points: 500,
      description: "جلسة صيانة كاملة مع تنظيف النظام"
    }
  ]
};

const CustomerDashboard = () => {
  const { toast } = useToast();
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [showWaterQuality, setShowWaterQuality] = useState(false);
  const [showLoyaltyProgram, setShowLoyaltyProgram] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);

  const handleMaintenanceRequest = (deviceId: string) => {
    toast({
      title: "تم إرسال طلب الصيانة",
      description: "سيتم التواصل معكم قريباً لتحديد موعد الصيانة",
    });
  };

  const handleDeviceDetails = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };

  const handleWaterQuality = (device: Device) => {
    setSelectedDevice(device);
    setShowWaterQuality(true);
  };

  const handleRedeemPoints = (points: number) => {
    toast({
      title: "تم استبدال النقاط بنجاح",
      description: `تم خصم ${points} نقطة من رصيدك`,
    });
  };

  return (
    <div className="container mx-auto p-6">
      <CustomerHeader 
        name={commercialCustomer?.name || ''} 
        loyaltyPoints={commercialCustomer?.loyaltyPoints}
      />

      <div className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <LoyaltyProgramCard
              pointsEarned={loyaltyProgram.pointsEarned}
              onShowDetails={() => setShowLoyaltyProgram(true)}
            />
          </div>
        </div>
      </div>

      <QuickStats
        activeDevices={commercialCustomer?.devices?.length || 0}
        waterQuality="98%"
        nextMaintenance="خلال 15 يوم"
        monthlySavings="15%"
      />

      <DeviceList
        devices={commercialCustomer?.devices || []}
        onShowDetails={handleDeviceDetails}
        onShowWaterQuality={handleWaterQuality}
        onMaintenanceRequest={handleMaintenanceRequest}
      />

      <DeviceDetailsDialog
        open={showDeviceDetails}
        onOpenChange={setShowDeviceDetails}
        device={selectedDevice}
      />

      <WaterQualityDialog
        open={showWaterQuality}
        onOpenChange={setShowWaterQuality}
        device={selectedDevice}
      />

      <LoyaltyProgramDialog
        open={showLoyaltyProgram}
        onOpenChange={setShowLoyaltyProgram}
        program={loyaltyProgram}
        onRedeemPoints={handleRedeemPoints}
      />
    </div>
  );
};

export default CustomerDashboard;
