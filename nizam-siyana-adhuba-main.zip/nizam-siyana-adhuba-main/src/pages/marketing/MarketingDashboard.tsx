
import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { AreaDiscountsCard } from '@/components/marketing/AreaDiscountsCard';
import { MarketingCampaignsCard } from '@/components/marketing/MarketingCampaignsCard';
import { AreaDiscountsDialog } from '@/components/marketing/AreaDiscountsDialog';
import { MarketingCampaignsDialog } from '@/components/marketing/MarketingCampaignsDialog';
import type { MarketingCampaign } from '@/types/marketing';

interface AreaDiscount {
  areaName: string;
  discountPercentage: number;
  validUntil: string;
  minimumPurchase?: number;
  servicesIncluded: string[];
}

export const MarketingDashboard = () => {
  const { toast } = useToast();
  const [showAreaDiscounts, setShowAreaDiscounts] = useState(false);
  const [showCampaigns, setShowCampaigns] = useState(false);

  const areaDiscounts: AreaDiscount[] = [
    {
      areaName: "الدرعية",
      discountPercentage: 100,
      validUntil: "2024-06-30",
      servicesIncluded: ["تركيب", "صيانة أولى"],
    },
    {
      areaName: "النخيل",
      discountPercentage: 25,
      validUntil: "2024-05-15",
      minimumPurchase: 1000,
      servicesIncluded: ["تركيب", "صيانة", "قطع غيار"],
    }
  ];

  const marketingCampaigns: MarketingCampaign[] = [
    {
      id: "CAM001",
      name: "حملة الصيف",
      platform: "سناب شات",
      targetArea: "شمال الرياض",
      budget: 5000,
      duration: "30 يوم",
      type: "seasonal",
      startDate: "2024-06-01",
      endDate: "2024-06-30",
      targetAudience: "العملاء السكنيين",
      reach: 2500,
      status: "active",
      description: "حملة موجهة لسكان شمال الرياض",
      engagement: 1500
    },
    {
      id: "CAM002",
      name: "حملة الشركات",
      platform: "تويتر",
      targetArea: "الرياض الكبرى",
      budget: 7000,
      duration: "45 يوم",
      type: "business",
      startDate: "2024-07-01",
      endDate: "2024-08-15",
      targetAudience: "الشركات",
      reach: 0,
      status: "scheduled",
      description: "حملة موجهة للشركات في الرياض",
      engagement: 0
    }
  ];

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">التسويق والتوسع</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <AreaDiscountsCard
          discountCount={areaDiscounts.length}
          onShowDetails={() => setShowAreaDiscounts(true)}
        />
        <MarketingCampaignsCard
          campaignCount={marketingCampaigns.length}
          onShowDetails={() => setShowCampaigns(true)}
        />
      </div>

      <AreaDiscountsDialog
        open={showAreaDiscounts}
        onOpenChange={setShowAreaDiscounts}
        discounts={areaDiscounts}
      />

      <MarketingCampaignsDialog
        open={showCampaigns}
        onOpenChange={setShowCampaigns}
        campaigns={marketingCampaigns}
      />
    </div>
  );
};

export default MarketingDashboard;
