
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

const supabaseUrl = 'https://wizgixxljcsifflzbbmm.supabase.co';
const supabaseKey = process.env.VITE_SUPABASE_KEY || '';

export const supabase = createClient<Database>(supabaseUrl, supabaseKey);
