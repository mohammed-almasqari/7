
import React, { createContext, useContext, useState } from 'react';
import type { UserRole } from '@/types/user';
import { useToast } from "@/components/ui/use-toast";
import { localAuth, UserProfile } from '@/services/auth/localAuth';

interface AuthContextType {
  user: UserProfile | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  hasPermission: (permission: string) => boolean;
  canAccessCustomerData: (customerId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const { toast } = useToast();

  const login = async (email: string, password: string) => {
    try {
      const userData = await localAuth.signIn(email, password);
      setUser(userData);
      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: `مرحباً بك ${userData.name}`,
      });
    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الدخول",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const signup = async (email: string, password: string, name: string) => {
    try {
      await localAuth.signUp(email, password, name);
      toast({
        title: "تم إنشاء الحساب بنجاح",
        description: "يمكنك الآن تسجيل الدخول",
      });
    } catch (error: any) {
      toast({
        title: "خطأ في إنشاء الحساب",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await localAuth.signOut();
      setUser(null);
      toast({
        title: "تم تسجيل الخروج بنجاح",
      });
    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الخروج",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    
    if (user.role === 'admin') {
      const restrictedPermissions = ['edit_maintenance_reports'];
      if (restrictedPermissions.includes(permission)) {
        return false;
      }
      return true;
    }

    return false;
  };

  const canAccessCustomerData = (customerId: string): boolean => {
    if (!user) return false;

    switch (user.role) {
      case 'admin':
        return true;
      case 'technician':
        return true;
      case 'customer':
        return user.id === customerId;
      default:
        return false;
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout,
      signup,
      hasPermission, 
      canAccessCustomerData 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
