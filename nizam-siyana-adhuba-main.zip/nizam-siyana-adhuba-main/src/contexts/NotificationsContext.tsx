
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { MaintenanceTicket, TicketUpdate } from '@/types/ticket';

interface NotificationEvent {
  id: string;
  type: 'ticket_created' | 'ticket_updated' | 'report_submitted' | 'assignment_changed' | 'maintenance_scheduled' | 'maintenance_alert';
  timestamp: string;
  data: {
    ticketId?: string;
    message: string;
    priority?: 'low' | 'medium' | 'high';
    reportId?: string;
    scheduleId?: string;
  };
}

interface NotificationsContextType {
  notifications: NotificationEvent[];
  markAsRead: (id: string) => void;
  sendNotification: (notification: Omit<NotificationEvent, 'id' | 'timestamp'>) => void;
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined);

export const NotificationsProvider = ({ children }: { children: React.ReactNode }) => {
  const [notifications, setNotifications] = useState<NotificationEvent[]>([]);
  const { toast } = useToast();

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const sendNotification = (notification: Omit<NotificationEvent, 'id' | 'timestamp'>) => {
    const newNotification: NotificationEvent = {
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    };

    setNotifications(prev => [newNotification, ...prev]);

    // Show toast notification
    toast({
      title: "إشعار جديد",
      description: notification.data.message,
    });
  };

  return (
    <NotificationsContext.Provider value={{ notifications, markAsRead, sendNotification }}>
      {children}
    </NotificationsContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationsContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationsProvider');
  }
  return context;
};
