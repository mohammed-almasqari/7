
class CacheService {
  private static cache = new Map<string, { data: any; timestamp: number }>();
  private static DEFAULT_TTL = 5 * 60 * 1000; // 5 minutes in milliseconds

  static set(key: string, data: any, ttl: number = this.DEFAULT_TTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now() + ttl
    });
  }

  static get(key: string): any | null {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() > item.timestamp) {
      this.cache.delete(key);
      return null;
    }

    return item.data;
  }

  static clear(): void {
    this.cache.clear();
  }

  static remove(key: string): void {
    this.cache.delete(key);
  }
}

export default CacheService;
