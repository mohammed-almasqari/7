
import { SystemVersion, UpdateStatus, ServerConfig } from '@/types/system';

class UpdateService {
  private static async fetchWithTimeout(url: string, options: RequestInit = {}, timeout = 30000) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(id);
      return response;
    } catch (error) {
      clearTimeout(id);
      throw error;
    }
  }

  static async getCurrentVersion(): Promise<SystemVersion> {
    const response = await this.fetchWithTimeout('/api/system/version');
    if (!response.ok) {
      throw new Error('فشل في الحصول على إصدار النظام');
    }
    return response.json();
  }

  static async startUpdate(config: ServerConfig): Promise<void> {
    const response = await this.fetchWithTimeout('/api/system/update/start', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(config)
    });

    if (!response.ok) {
      throw new Error('فشل في بدء عملية التحديث');
    }
  }

  static async getUpdateStatus(): Promise<UpdateStatus> {
    const response = await this.fetchWithTimeout('/api/system/update/status');
    if (!response.ok) {
      throw new Error('فشل في الحصول على حالة التحديث');
    }
    return response.json();
  }

  static async verifyUpdate(): Promise<boolean> {
    const response = await this.fetchWithTimeout('/api/system/update/verify');
    if (!response.ok) {
      throw new Error('فشل في التحقق من التحديث');
    }
    const { success } = await response.json();
    return success;
  }

  static async cancelUpdate(): Promise<void> {
    const response = await this.fetchWithTimeout('/api/system/update/cancel', {
      method: 'POST'
    });
    if (!response.ok) {
      throw new Error('فشل في إلغاء التحديث');
    }
  }
}

export default UpdateService;
