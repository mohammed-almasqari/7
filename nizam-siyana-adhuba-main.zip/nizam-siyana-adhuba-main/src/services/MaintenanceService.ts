
import { supabase } from '@/integrations/supabase/client';
import CacheService from './CacheService';
import type { MaintenanceTicket, TicketUpdate } from '@/types/ticket';
import type { Json } from '@/integrations/supabase/types';

export class MaintenanceService {
  private static CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  private static TICKETS_CACHE_KEY = 'maintenance_tickets';

  private static transformDatabaseTicket(data: any): MaintenanceTicket {
    return {
      id: data.id,
      customer_id: data.customer_id,
      technician_id: data.technician_id,
      device_id: data.device_id,
      status: data.status,
      priority: data.priority,
      description: data.description,
      created_at: data.created_at,
      scheduled_for: data.scheduled_for,
      location: typeof data.location === 'object' ? data.location : { address: '' },
      updates: data.ticket_updates?.map((update: any) => ({
        id: update.id,
        ticket_id: update.ticket_id,
        timestamp: update.created_at,
        type: update.type,
        content: update.content,
        author: {
          id: update.author_id,
          name: 'Unknown', // This should be fetched from profiles table
          role: 'admin'
        }
      })) || []
    };
  }

  static async createTicket(ticket: Omit<MaintenanceTicket, 'id' | 'created_at' | 'updates'>): Promise<MaintenanceTicket> {
    const { data, error } = await supabase
      .from('maintenance_tickets')
      .insert({
        customer_id: ticket.customer_id,
        device_id: ticket.device_id,
        status: ticket.status,
        priority: ticket.priority,
        description: ticket.description,
        location: ticket.location,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    CacheService.remove(this.TICKETS_CACHE_KEY);
    
    return this.transformDatabaseTicket(data);
  }

  static async getTickets(): Promise<MaintenanceTicket[]> {
    const cachedTickets = CacheService.get(this.TICKETS_CACHE_KEY);
    if (cachedTickets) return cachedTickets;

    const { data, error } = await supabase
      .from('maintenance_tickets')
      .select(`
        *,
        ticket_updates (
          id,
          ticket_id,
          created_at,
          type,
          content,
          author_id
        )
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const ticketsWithUpdates = data.map(ticket => this.transformDatabaseTicket(ticket));

    CacheService.set(this.TICKETS_CACHE_KEY, ticketsWithUpdates, this.CACHE_TTL);
    
    return ticketsWithUpdates;
  }

  static async updateTicket(
    ticketId: string, 
    update: Omit<TicketUpdate, 'id' | 'ticket_id' | 'timestamp'>
  ): Promise<MaintenanceTicket> {
    const { data: ticketUpdate, error: updateError } = await supabase
      .from('ticket_updates')
      .insert({
        ticket_id: ticketId,
        content: update.content,
        type: update.type,
        author_id: update.author.id,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (updateError) throw updateError;

    const { data: updatedTicket, error: ticketError } = await supabase
      .from('maintenance_tickets')
      .select(`
        *,
        ticket_updates (
          id,
          ticket_id,
          created_at,
          type,
          content,
          author_id
        )
      `)
      .eq('id', ticketId)
      .single();

    if (ticketError) throw ticketError;

    CacheService.remove(this.TICKETS_CACHE_KEY);

    return this.transformDatabaseTicket(updatedTicket);
  }

  static async completeTicket(
    ticketId: string,
    report: {
      findings: string;
      actions: string;
      recommendations?: string;
      parts_used?: string[];
      technician_notes?: string;
    }
  ): Promise<MaintenanceTicket> {
    // Insert maintenance report according to the database schema
    // Combine findings, actions and recommendations into a single notes field
    const notesContent = `Findings: ${report.findings}\nActions: ${report.actions}${report.recommendations ? '\nRecommendations: ' + report.recommendations : ''}`;
    
    const { error: reportError } = await supabase
      .from('maintenance_reports')
      .insert({
        ticket_id: ticketId,
        notes: notesContent,
        parts_used: report.parts_used ? report.parts_used as Json : null,
        technician_id: 'system', // Required field in the database schema
        status: 'completed'
      });

    if (reportError) throw reportError;

    await this.updateTicket(ticketId, {
      type: 'report',
      content: 'تم إكمال الصيانة وإصدار التقرير',
      author: {
        id: 'system',
        name: 'النظام',
        role: 'admin'
      }
    });

    const { data: ticket, error: ticketError } = await supabase
      .from('maintenance_tickets')
      .update({ status: 'completed' as const })
      .eq('id', ticketId)
      .select(`
        *,
        ticket_updates (
          id,
          ticket_id,
          created_at,
          type,
          content,
          author_id
        )
      `)
      .single();

    if (ticketError) throw ticketError;

    CacheService.remove(this.TICKETS_CACHE_KEY);

    return this.transformDatabaseTicket(ticket);
  }

  static async simulateMaintenanceFlow(deviceId: string, customerId: string): Promise<void> {
    // 1. Create new ticket
    const ticket = await this.createTicket({
      customer_id: customerId,
      device_id: deviceId,
      status: 'new',
      priority: 'medium',
      description: 'صيانة دورية للجهاز',
      location: {
        address: 'شارع الملك فهد، الرياض'
      }
    });

    // 2. Assign technician
    await this.updateTicket(ticket.id, {
      type: 'assignment',
      content: 'تم تعيين الفني محمد أحمد',
      author: {
        id: 'admin1',
        name: 'مدير النظام',
        role: 'admin'
      }
    });

    // 3. Update status to in progress
    await this.updateTicket(ticket.id, {
      type: 'status_change',
      content: 'بدأ العمل على الصيانة',
      author: {
        id: 'tech1',
        name: 'محمد أحمد',
        role: 'technician'
      }
    });

    // 4. Add maintenance notes
    await this.updateTicket(ticket.id, {
      type: 'note',
      content: 'تم فحص الجهاز وتنظيف الفلاتر',
      author: {
        id: 'tech1',
        name: 'محمد أحمد',
        role: 'technician'
      }
    });

    // 5. Complete maintenance and create report
    await this.completeTicket(ticket.id, {
      findings: 'الجهاز في حالة جيدة مع حاجة لتغيير الفلتر',
      actions: 'تم تنظيف الجهاز وتغيير الفلتر',
      recommendations: 'يُنصح بتغيير الفلتر كل 3 أشهر',
      parts_used: ['فلتر مياه جديد', 'حلقات منع التسرب'],
      technician_notes: 'تم إكمال الصيانة بنجاح'
    });
  }
}
