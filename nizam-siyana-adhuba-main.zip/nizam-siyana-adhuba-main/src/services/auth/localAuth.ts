
import type { UserRole } from '@/types/user';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

// محاكاة قاعدة بيانات المستخدمين
const users: UserProfile[] = [
  // حساب المدير
  {
    id: '1',
    name: 'أحمد المدير',
    email: 'admin@athoba.com',
    role: 'admin'
  },
  // حساب الفني
  {
    id: '2',
    name: 'محمد الفني',
    email: 'tech@athoba.com',
    role: 'technician'
  },
  // حساب العميل
  {
    id: '3',
    name: 'عبدالله العميل',
    email: 'customer@athoba.com',
    role: 'customer'
  }
];

export const localAuth = {
  async signIn(email: string, password: string): Promise<UserProfile> {
    const user = users.find(u => u.email === email);
    if (!user) {
      throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    }
    return user;
  },

  async signUp(email: string, password: string, name: string): Promise<UserProfile> {
    if (users.some(u => u.email === email)) {
      throw new Error('البريد الإلكتروني مستخدم بالفعل');
    }

    const newUser: UserProfile = {
      id: String(users.length + 1),
      name,
      email,
      role: 'customer'
    };

    users.push(newUser);
    return newUser;
  },

  async signOut(): Promise<void> {
    // محاكاة عملية تسجيل الخروج
    return Promise.resolve();
  },

  async getSession(): Promise<UserProfile | null> {
    // في الإصدار المحلي، نفترض عدم وجود جلسة محفوظة
    return null;
  }
};
