
import { supabase } from '@/lib/supabase';
import { Database } from '@/types/database';

type SystemUpdate = Database['public']['Tables']['system_updates']['Row'];
type SystemLog = Database['public']['Tables']['system_logs']['Row'];

export class SystemUpdateService {
  static async createUpdate(version: string, initiatedBy: string) {
    const { data, error } = await supabase
      .from('system_updates')
      .insert({
        version,
        status: 'pending',
        initiated_by: initiatedBy
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async getLastUpdate() {
    const { data, error } = await supabase
      .from('system_updates')
      .select()
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error) throw error;
    return data;
  }

  static async updateStatus(
    id: string, 
    status: SystemUpdate['status'], 
    errorMessage?: string
  ) {
    const { data, error } = await supabase
      .from('system_updates')
      .update({
        status,
        error_message: errorMessage,
        completed_at: status === 'completed' ? new Date().toISOString() : null
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async logSystemEvent(
    level: SystemLog['level'],
    message: string,
    metadata?: Record<string, any>
  ) {
    const { error } = await supabase
      .from('system_logs')
      .insert({
        level,
        message,
        metadata
      });

    if (error) throw error;
  }

  static async getSystemLogs(limit = 100) {
    const { data, error } = await supabase
      .from('system_logs')
      .select()
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  }
}
